#!/bin/bash
echo "$@\n" >> $HOME/Desktop/OsiriX.exec.txt