#import <Cocoa/Cocoa.h>
@class   HTTPServer;

@interface AppDelegate : NSObject
{
	HTTPServer *httpServer;
}
@end
