#ifndef _expatDllConfig_h
#define _expatDllConfig_h

/* #undef ITK_EXPAT_STATIC */

#endif
