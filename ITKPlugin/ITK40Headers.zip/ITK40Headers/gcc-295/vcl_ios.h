#ifndef vcl_gcc_295_ios_h_
#define vcl_gcc_295_ios_h_

#include <vcl_iostream.h>
#define vcl_generic_ios_STD /* */
#define vcl_ios_boolalpha 0
#include "generic/vcl_ios.h"

#endif
