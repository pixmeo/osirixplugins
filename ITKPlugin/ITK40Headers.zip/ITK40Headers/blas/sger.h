extern int v3p_netlib_sger_(
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_real *alpha,
  v3p_netlib_real *x,
  v3p_netlib_integer *incx,
  v3p_netlib_real *y,
  v3p_netlib_integer *incy,
  v3p_netlib_real *a,
  v3p_netlib_integer *lda
  );
