extern int v3p_netlib_dger_(
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *alpha,
  v3p_netlib_doublereal *x,
  v3p_netlib_integer *incx,
  v3p_netlib_doublereal *y,
  v3p_netlib_integer *incy,
  v3p_netlib_doublereal *a,
  v3p_netlib_integer *lda
  );
