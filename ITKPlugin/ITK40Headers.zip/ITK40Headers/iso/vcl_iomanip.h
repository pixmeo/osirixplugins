#ifndef vcl_iso_iomanip_h_
#define vcl_iso_iomanip_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <iomanip>

#ifdef vcl_generic_iomanip_STD
  ** error **
#else
# define vcl_generic_iomanip_STD std
#endif

#include "../generic/vcl_iomanip.h"

#endif // vcl_iso_iomanip_h_
