#ifndef vcl_iso_cstring_h_
#define vcl_iso_cstring_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <cstring>

#ifdef vcl_generic_cstring_STD
  ** error **
#else
# define vcl_generic_cstring_STD std
#endif

#include "../generic/vcl_cstring.h"

#endif // vcl_iso_cstring_h_
