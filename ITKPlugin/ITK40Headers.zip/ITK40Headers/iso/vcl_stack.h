#ifndef vcl_iso_stack_h_
#define vcl_iso_stack_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <stack>

#ifdef vcl_generic_stack_STD
  ** error **
#else
# define vcl_generic_stack_STD std
#endif

#include "../generic/vcl_stack.h"

#endif // vcl_iso_stack_h_
