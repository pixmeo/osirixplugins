#ifndef vcl_iso_cmath_h_
#define vcl_iso_cmath_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <cmath>

#ifdef vcl_generic_cmath_STD
  ** error **
#else
# define vcl_generic_cmath_STD std
#endif

#include "../generic/vcl_cmath.h"

#endif // vcl_iso_cmath_h_
