#ifndef vcl_iso_ostream_h_
#define vcl_iso_ostream_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <ostream>

#ifdef vcl_generic_ostream_STD
  ** error **
#else
# define vcl_generic_ostream_STD std
#endif

#include "../generic/vcl_ostream.h"

#endif // vcl_iso_ostream_h_
