#ifndef vcl_iso_map_h_
#define vcl_iso_map_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <map>

#ifdef vcl_generic_map_STD
  ** error **
#else
# define vcl_generic_map_STD std
#endif

#include "../generic/vcl_map.h"

#endif // vcl_iso_map_h_
