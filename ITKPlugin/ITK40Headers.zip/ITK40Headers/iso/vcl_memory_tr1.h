#ifndef vcl_iso_memory_tr1_h_
#define vcl_iso_memory_tr1_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <memory_tr1>

#ifdef vcl_generic_memory_tr1_STD
  ** error **
#else
# define vcl_generic_memory_tr1_STD std
#endif

#include "../generic/vcl_memory_tr1.h"

#endif // vcl_iso_memory_tr1_h_
