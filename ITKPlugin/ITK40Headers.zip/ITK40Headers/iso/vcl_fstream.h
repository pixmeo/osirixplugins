#ifndef vcl_iso_fstream_h_
#define vcl_iso_fstream_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <fstream>

#ifdef vcl_generic_fstream_STD
  ** error **
#else
# define vcl_generic_fstream_STD std
#endif

#include "../generic/vcl_fstream.h"

#endif // vcl_iso_fstream_h_
