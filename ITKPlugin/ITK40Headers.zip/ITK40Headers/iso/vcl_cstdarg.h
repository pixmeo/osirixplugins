#ifndef vcl_iso_cstdarg_h_
#define vcl_iso_cstdarg_h_

// This is a generated file. DO NOT EDIT! Not even a little bit.

#include <cstdarg>

#ifdef vcl_generic_cstdarg_STD
  ** error **
#else
# define vcl_generic_cstdarg_STD std
#endif

#include "../generic/vcl_cstdarg.h"

#endif // vcl_iso_cstdarg_h_
