#ifndef vcl_emulation_ciso646_h_
#define vcl_emulation_ciso646_h_

#define and    &&
#define and_eq &=
#define bitand &
#define bitor  |
#define compl  ~
#define not    !
#define not_eq !=
#define or     ||
#define or_eq  |=
#define xor    ^
#define xor_eq ^=

#endif // vcl_emulation_ciso646_h_
