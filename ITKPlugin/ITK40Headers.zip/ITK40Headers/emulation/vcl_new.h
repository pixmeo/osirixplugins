#ifndef vcl_emulation_new_h_
#define vcl_emulation_new_h_
/*
  fsm
*/

#include <vcl_compiler.h>

#include <new.h>

// for vcl_destroy() and vcl_construct() :
#include "vcl_algobase.h"

#endif // vcl_emulation_new_h_
