#ifndef vcl_generic_typeinfo_h_
#define vcl_generic_typeinfo_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_typeinfo.hhh and run make

// type_info
#ifndef vcl_type_info
#define vcl_type_info vcl_generic_typeinfo_STD :: type_info
#endif
// bad_cast
#ifndef vcl_bad_cast
#define vcl_bad_cast vcl_generic_typeinfo_STD :: bad_cast
#endif
// bad_typeid
#ifndef vcl_bad_typeid
#define vcl_bad_typeid vcl_generic_typeinfo_STD :: bad_typeid
#endif

#endif // vcl_generic_typeinfo_h_
