#ifndef vcl_generic_bitset_h_
#define vcl_generic_bitset_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_bitset.hhh and run make

// bitset
#ifndef vcl_bitset
#define vcl_bitset vcl_generic_bitset_STD :: bitset
#endif

#endif // vcl_generic_bitset_h_
