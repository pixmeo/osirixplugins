#ifndef vcl_generic_ctime_h_
#define vcl_generic_ctime_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_ctime.hhh and run make

// NB: size_t is declared in <cstddef>, not <ctime>
// clock_t
#ifndef vcl_clock_t
#define vcl_clock_t vcl_generic_ctime_STD :: clock_t
#endif
// time_t
#ifndef vcl_time_t
#define vcl_time_t vcl_generic_ctime_STD :: time_t
#endif
// tm
#ifndef vcl_tm
#define vcl_tm vcl_generic_ctime_STD :: tm
#endif
// asctime
#ifndef vcl_asctime
#define vcl_asctime vcl_generic_ctime_STD :: asctime
#endif
// clock
#ifndef vcl_clock
#define vcl_clock vcl_generic_ctime_STD :: clock
#endif
// difftime
#ifndef vcl_difftime
#define vcl_difftime vcl_generic_ctime_STD :: difftime
#endif
// localtime
#ifndef vcl_localtime
#define vcl_localtime vcl_generic_ctime_STD :: localtime
#endif
// strftime
#ifndef vcl_strftime
#define vcl_strftime vcl_generic_ctime_STD :: strftime
#endif
// ctime
#ifndef vcl_ctime
#define vcl_ctime vcl_generic_ctime_STD :: ctime
#endif
// gmtime
#ifndef vcl_gmtime
#define vcl_gmtime vcl_generic_ctime_STD :: gmtime
#endif
// mktime
#ifndef vcl_mktime
#define vcl_mktime vcl_generic_ctime_STD :: mktime
#endif
// time
#ifndef vcl_time
#define vcl_time vcl_generic_ctime_STD :: time
#endif

#endif // vcl_generic_ctime_h_
