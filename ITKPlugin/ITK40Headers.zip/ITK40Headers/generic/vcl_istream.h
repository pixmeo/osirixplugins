#ifndef vcl_generic_istream_h_
#define vcl_generic_istream_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_istream.hhh and run make

// basic_istream
#ifndef vcl_basic_istream
#define vcl_basic_istream vcl_generic_istream_STD :: basic_istream
#endif
// istream
#ifndef vcl_istream
#define vcl_istream vcl_generic_istream_STD :: istream
#endif
// wistream
#ifndef vcl_wistream
#define vcl_wistream vcl_generic_istream_STD :: wistream
#endif
// basic_iostream
#ifndef vcl_basic_iostream
#define vcl_basic_iostream vcl_generic_istream_STD :: basic_iostream
#endif
// iostream
#ifndef vcl_iostream
#define vcl_iostream vcl_generic_istream_STD :: iostream
#endif
// wiostream
#ifndef vcl_wiostream
#define vcl_wiostream vcl_generic_istream_STD :: wiostream
#endif

#endif // vcl_generic_istream_h_
