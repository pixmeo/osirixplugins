#ifndef vcl_generic_csignal_h_
#define vcl_generic_csignal_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_csignal.hhh and run make

// sig_atomic_t
#ifndef vcl_sig_atomic_t
#define vcl_sig_atomic_t vcl_generic_csignal_STD :: sig_atomic_t
#endif
// raise
#ifndef vcl_raise
#define vcl_raise vcl_generic_csignal_STD :: raise
#endif
// signal
#ifndef vcl_signal
#define vcl_signal vcl_generic_csignal_STD :: signal
#endif

#endif // vcl_generic_csignal_h_
