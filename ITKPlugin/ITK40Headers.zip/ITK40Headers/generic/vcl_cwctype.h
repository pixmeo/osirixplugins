#ifndef vcl_generic_cwctype_h_
#define vcl_generic_cwctype_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_cwctype.hhh and run make

// wctrans_t
#ifndef vcl_wctrans_t
#define vcl_wctrans_t vcl_generic_cwctype_STD :: wctrans_t
#endif
// wctype_t
#ifndef vcl_wctype_t
#define vcl_wctype_t vcl_generic_cwctype_STD :: wctype_t
#endif
// wint_t
#ifndef vcl_wint_t
#define vcl_wint_t vcl_generic_cwctype_STD :: wint_t
#endif
// iswalnum
#ifndef vcl_iswalnum
#define vcl_iswalnum vcl_generic_cwctype_STD :: iswalnum
#endif
// iswalpha
#ifndef vcl_iswalpha
#define vcl_iswalpha vcl_generic_cwctype_STD :: iswalpha
#endif
// iswcntrl
#ifndef vcl_iswcntrl
#define vcl_iswcntrl vcl_generic_cwctype_STD :: iswcntrl
#endif
// iswctype
#ifndef vcl_iswctype
#define vcl_iswctype vcl_generic_cwctype_STD :: iswctype
#endif
// iswdigit
#ifndef vcl_iswdigit
#define vcl_iswdigit vcl_generic_cwctype_STD :: iswdigit
#endif
// iswgraph
#ifndef vcl_iswgraph
#define vcl_iswgraph vcl_generic_cwctype_STD :: iswgraph
#endif
// iswlower
#ifndef vcl_iswlower
#define vcl_iswlower vcl_generic_cwctype_STD :: iswlower
#endif
// iswprint
#ifndef vcl_iswprint
#define vcl_iswprint vcl_generic_cwctype_STD :: iswprint
#endif
// iswpunct
#ifndef vcl_iswpunct
#define vcl_iswpunct vcl_generic_cwctype_STD :: iswpunct
#endif
// iswspace
#ifndef vcl_iswspace
#define vcl_iswspace vcl_generic_cwctype_STD :: iswspace
#endif
// iswupper
#ifndef vcl_iswupper
#define vcl_iswupper vcl_generic_cwctype_STD :: iswupper
#endif
// iswxdigit
#ifndef vcl_iswxdigit
#define vcl_iswxdigit vcl_generic_cwctype_STD :: iswxdigit
#endif
// iswctrans
#ifndef vcl_iswctrans
#define vcl_iswctrans vcl_generic_cwctype_STD :: iswctrans
#endif
// iswupper
#ifndef vcl_iswupper
#define vcl_iswupper vcl_generic_cwctype_STD :: iswupper
#endif
// iswxdigit
#ifndef vcl_iswxdigit
#define vcl_iswxdigit vcl_generic_cwctype_STD :: iswxdigit
#endif
// towctrans
#ifndef vcl_towctrans
#define vcl_towctrans vcl_generic_cwctype_STD :: towctrans
#endif
// towlower
#ifndef vcl_towlower
#define vcl_towlower vcl_generic_cwctype_STD :: towlower
#endif
// towupper
#ifndef vcl_towupper
#define vcl_towupper vcl_generic_cwctype_STD :: towupper
#endif
// wctrans
#ifndef vcl_wctrans
#define vcl_wctrans vcl_generic_cwctype_STD :: wctrans
#endif
// wctype
#ifndef vcl_wctype
#define vcl_wctype vcl_generic_cwctype_STD :: wctype
#endif

#endif // vcl_generic_cwctype_h_
