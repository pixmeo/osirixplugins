#ifndef vcl_generic_streambuf_h_
#define vcl_generic_streambuf_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_streambuf.hhh and run make

// basic_streambuf
#ifndef vcl_basic_streambuf
#define vcl_basic_streambuf vcl_generic_streambuf_STD :: basic_streambuf
#endif
// streambuf
#ifndef vcl_streambuf
#define vcl_streambuf vcl_generic_streambuf_STD :: streambuf
#endif

#endif // vcl_generic_streambuf_h_
