#ifndef vcl_generic_stack_h_
#define vcl_generic_stack_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_stack.hhh and run make

// stack
#ifndef vcl_stack
#define vcl_stack vcl_generic_stack_STD :: stack
#endif

#endif // vcl_generic_stack_h_
