#ifndef vcl_generic_utility_h_
#define vcl_generic_utility_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_utility.hhh and run make

// pair
#ifndef vcl_pair
#define vcl_pair vcl_generic_utility_STD :: pair
#endif
// make_pair
#ifndef vcl_make_pair
#define vcl_make_pair vcl_generic_utility_STD :: make_pair
#endif

#endif // vcl_generic_utility_h_
