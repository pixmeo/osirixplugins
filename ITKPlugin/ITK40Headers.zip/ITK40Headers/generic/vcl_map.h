#ifndef vcl_generic_map_h_
#define vcl_generic_map_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_map.hhh and run make

// map
#ifndef vcl_map
#define vcl_map vcl_generic_map_STD :: map
#endif
// multimap
#ifndef vcl_multimap
#define vcl_multimap vcl_generic_map_STD :: multimap
#endif
// swap
#ifndef vcl_swap
#define vcl_swap vcl_generic_map_STD :: swap
#endif

#endif // vcl_generic_map_h_
