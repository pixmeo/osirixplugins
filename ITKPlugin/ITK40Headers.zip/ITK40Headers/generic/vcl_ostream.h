#ifndef vcl_generic_ostream_h_
#define vcl_generic_ostream_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_ostream.hhh and run make

// basic_ostream
#ifndef vcl_basic_ostream
#define vcl_basic_ostream vcl_generic_ostream_STD :: basic_ostream
#endif
// ostream
#ifndef vcl_ostream
#define vcl_ostream vcl_generic_ostream_STD :: ostream
#endif
// wostream
#ifndef vcl_wostream
#define vcl_wostream vcl_generic_ostream_STD :: wostream
#endif
// endl
#ifndef vcl_endl
#define vcl_endl vcl_generic_ostream_STD :: endl
#endif
// ends
#ifndef vcl_ends
#define vcl_ends vcl_generic_ostream_STD :: ends
#endif
// flush
#ifndef vcl_flush
#define vcl_flush vcl_generic_ostream_STD :: flush
#endif

#endif // vcl_generic_ostream_h_
