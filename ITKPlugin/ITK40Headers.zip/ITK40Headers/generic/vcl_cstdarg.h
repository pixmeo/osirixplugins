#ifndef vcl_generic_cstdarg_h_
#define vcl_generic_cstdarg_h_

// THIS IS A GENERATED FILE. DO NOT EDIT! -- Instead, edit vcl_cstdarg.hhh and run make

// va_list
#ifndef vcl_va_list
#define vcl_va_list vcl_generic_cstdarg_STD :: va_list
#endif

#endif // vcl_generic_cstdarg_h_
