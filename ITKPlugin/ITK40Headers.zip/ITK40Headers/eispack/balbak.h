extern int v3p_netlib_balbak_(
  v3p_netlib_integer *nm,
  v3p_netlib_integer *n,
  v3p_netlib_integer *low,
  v3p_netlib_integer *igh,
  v3p_netlib_doublereal *scale,
  v3p_netlib_integer *m,
  v3p_netlib_doublereal *z__
  );
