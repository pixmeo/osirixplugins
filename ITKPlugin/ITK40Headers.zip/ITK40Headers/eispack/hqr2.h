extern int v3p_netlib_hqr2_(
  v3p_netlib_integer *nm,
  v3p_netlib_integer *n,
  v3p_netlib_integer *low,
  v3p_netlib_integer *igh,
  v3p_netlib_doublereal *h__,
  v3p_netlib_doublereal *wr,
  v3p_netlib_doublereal *wi,
  v3p_netlib_doublereal *z__,
  v3p_netlib_integer *ierr
  );
