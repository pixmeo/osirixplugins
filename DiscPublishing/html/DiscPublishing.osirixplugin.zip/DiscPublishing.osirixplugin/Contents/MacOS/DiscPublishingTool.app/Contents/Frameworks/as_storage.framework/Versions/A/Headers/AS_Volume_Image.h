//-----------------------------------------------------------------------------
// AS_Volume_Image.h
// Copyright (c) Corel Corporation or its subsidiaries. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef __AS_Volume_Image_h__
#define __AS_Volume_Image_h__

#include "AS_File.h"
#include "AS_Volume.h"

#ifdef __cplusplus
extern "C"
{
#endif

// Open a volume on a device and determine the logical format
AS_StorageError AS_API AS_OpenVolumeImage(
	const AS_File::Path& pathToImageFile, //  IN: Full path of image file
	AS_Volume::FS_Type& kind,             // OUT: Detected file system, if any
	AS_Volume& volume);                   // OUT: AS_Volume object

#ifdef __cplusplus
}
#endif

#endif //__AS_Volume_Image_h__
