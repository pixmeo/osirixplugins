//////////////////
// PTJOBMANAGER.H
//////////////////

#ifdef __cplusplus
extern "C" {
#endif

#import <JobProcessor/JobProcessor.h>
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the PT_JOBMANAGER_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// PT_JOBMANAGER_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef PTJOBMANAGER_EXPORTS
#define PT_JOBMANAGER_API __declspec(dllexport)
#else
#define PT_JOBMANAGER_API __declspec(dllimport)
#endif


/*******************************************************

			      Job Manager Defines     
                                        
*********************************************************/

///////////////////////////
//
//  API return values 
///////////////////////////
#define JM_OK	   			0			// TODO: CHANGE ALL THESE TO JM_API_XXX ?
#define JM_XML_OPEN_ERR		201
#define JM_XML_SAVE_ERR		202
#define JM_XML_ERROR		203
#define JM_INTERNAL_ERR		204
#define	JM_TRY_LATER		205
#define JM_NO_ROBOTS		206
#define JM_DRIVE_NOT_FOUND	207
#define JM_FILE_NOT_FOUND	208
#define JM_NO_FILE_SPECIFIED 209
#define JM_LOGGING_ERROR	210




//////////////////////////
// Module Info
//////////////////////////
#define MODULE_NAME					"PTJobManager.dll"
#define STRING_RESOURCE_NAME		"PTJobManagerStrings.dll"
#define STATUS_FILE_NAME			"Status/PTP_Status.xml"
#define INFO_FILE_NAME				"Status/PTP_Info.xml"
#define LOG_FILE_NAME				"Log/PTP_Log.txt"
#define COMPLETED_JOBS_FILE_NAME	"Status/PTP_CompletedJobs.xml"


//////////////////////////
// Registry stuff
//////////////////////////
#define REG_PATH				"Software\\Primera\\PTPublisher"
#define JM_JOB_ID_STRING		"CurrentJobID"
#define JM_STATUS_LOOP_DELAY	"StatusLoopDelay"

//////////////////////////
//
// XML Elements
// STATUS FILE
//
//////////////////////////

	
////////////////////////
// MISC DEFINES
////////////////////////
#define MAX_DRIVES_PER_ROBOT	4
#define MAX_ROBOTS				10
#define MAX_TOTAL_DRIVES		MAX_ROBOTS*MAX_DRIVES_PER_ROBOT
#define MAX_AUDIO_FILES			99		
#define MAX_ACTIVE_JOBS			MAX_ROBOTS*(MAX_DRIVES_PER_ROBOT+1)
#define DEFAULT_PREGAP			150



///////////////////////////
//
//  System State
//
//////////////////////////
#define SYSSTATE_IDLE		0
#define SYSSTATE_BUSY		1
#define SYSSTATE_ERROR		2 


////////////////////////////
//
// Drive Open/Close
//
////////////////////////////
#define JM_OPEN_DRIVE			0 
#define JM_CLOSE_DRIVE			1

#define JM_RETURN_IMMEDIATELY	0
#define JM_WAIT_UNTIL_COMPLETED	1


////////////////////////////
// 
// BUS TYPES (same as PrimoSDK.h)
//
////////////////////////////
#define  BUS_UNKNOWN		0
#define  BUS_ATAPI          1
#define  BUS_SCSI           2
#define  BUS_1394           3
#define  BUS_USB            4
#define  BUS_USB2           5

#define DISCTYPE_CD 0
#define DISCTYPE_DVD 1
#define DISCTYPE_DVDDL 2
#define DISCTYPE_BR 3
#define DISCTYPE_BR_DL 4
#define DISCTYPE_UNKNOWN 5

	

	
#define FileSys_ISO_Level_2_Long    0  // IN/OUT: ISO 9660 Level 2 with long names
#define FileSys_Joliet            1  // IN/OUT: Joliet
#define FileSys_UDF102            2 // IN/OUT: UDF 1.02
#define FileSys_UDF25             3 // IN/OUT: UDF 2.5
#define FileSys_UDF26             4 // IN/OUT: UDF 2.6	
#define FileSys_ISO_Level_1         5  // IN/OUT: ISO 9660 Level 1	
#define FileSys_ISO_Level_2         6  // IN/OUT: ISO 9660 Level 2	
#define FileSys_UDF15             7 // IN/OUT: UDF 1.5
#define FileSys_UDF2              8 // IN/OUT: UDF 2.0
#define FileSys_UDF201            9 // IN/OUT: UDF 2.01
#define FileSys_NONE			  99	
	//**************************************
//
// ENUMs
//
//**************************************
enum Search
{
	NOTFOUND,
	FOUND,
	SEARCHING
};



//**************************************
//
// Structures 
//
//**************************************
typedef struct tagJM_BinSelection
{
	bool fEnabled;
	int nLeftBinType;
	int nRightBinType;
	int nDefaultBin;
} JM_BinSelection, *pJM_BinSelection;


typedef struct tagJM_RobotInfo
{
	char	tszRobotName[256];
	UInt32	dwRobotType;
	UInt32	hRobotID;
	UInt32	dwNumDrives;
	UInt32	dwDriveIDs[MAX_DRIVES_PER_ROBOT];
	char	tszDriveName[MAX_DRIVES_PER_ROBOT][256];
	int		nSystemError;
} JM_RobotInfo, *pJM_RobotInfo;


typedef struct tagStatusThreadInfo
{
	char			tszStatusFile[256];
	char			tszCompletedJobsFile[256];
	char			tszInfoFile[256];
	MPEventID			hTerminateThreadEvent;
	MPEventID			hThreadTerminatedEvent;
	UInt32			dwNumRobots;
	JM_RobotInfo	RobotInfo[MAX_ROBOTS];

} StatusThreadInfo, *pStatusThreadInfo;


typedef struct tagJM_JobInfo
{
	UInt32		dwNumCopies;
	UInt32		dwCreateOpts;					// Disc Creation Options for PrimoSDK
	UInt32		dwWriteOpts;					// Disc Writing Options for PrimoSDK
	UInt32		dwFileSystem;
	UInt32		dwFileSystemBridge;
	UInt32		dwJobOpts;						// Job Options for recording
	UInt32		dwRecSpeed;
	UInt32		dwJobType;						// JOB_DATA, JOB_AUDIO, JOB_IMAGE, JOB_PRUInt32_ONLY
	UInt32		dwImageType;					// defines image type if dwImageType=JOB_IMAGE
	UInt32		dwImageMode;
	UInt32		dwSourceDriveID;				// Source Drive ID (for disc copy job)
	char		tszPrintFile[256];
	bool		fPrintSettingsOverride;			// flag to say if the printer settings are being overridden or not
	PTPrinterSettings2 PrintSettings;			// printer settings to override
	char		tszVolume[32+1];
	int			nMediaType;						// MEDIA_DVD or MEDIA_CD (for PrimoSDK)
	int			nDiscType;
	int			nSessions;
	char		tszJobName[256];	
	bool		fPreserveISOVar;
	bool		fWritePVD;
	UInt32		dwJMJobID;
	JM_RobotInfo RobotInfo;
	UInt32		dwJobError;	
	UInt32       dwDestDriveID;
	char		tszJobClient[256];
	bool        fProtectWithPTProtect;
	bool        fDeleteImage;
	bool		fUseAltBurn;
	char		tszMergeFile[256];
	bool		fDeleteTempImageFiles;
	bool		fDeleteTempMergeFiles;
    SInt32      dwColorCartWarnPercent;
    SInt32      dwBlackCartWarnPercent;
    SInt32      dwCyanCartWarnPercent;
    SInt32      dwMagentaCartWarnPercent;
    SInt32      dwYellowCartWarnPercent;
}JM_JobInfo, *pJM_JobInfo;


typedef struct tagJM_ActiveJob
{
	UInt32	hRobotID;
	UInt32	dwNumDrives;
	UInt32	dwDriveIDs[MAX_DRIVES_PER_ROBOT];
	UInt32	dwJMJobID;
	char	tszJobName[256];
	char	tszRobotName[256];
	char	tszClient[256];
	bool    fNetworkJob;
	bool	fDeleteImageFiles;
	bool	fDeleteMergeFiles;
	char	tszMergeFile[256];
	char	tszImageFile[256];
} JM_ActiveJob, *pJM_ActiveJob;


#define MAX_FILE_VERSIONS 50
typedef struct tagFileVersionInfo
{
	char	tszName[MAX_FILE_VERSIONS][256];
	char	tszVersion[MAX_FILE_VERSIONS][20];
}	FileVersionInfo;


/*******************************************************

				Job Manager exported functions

*********************************************************/


////////////////////////////////////////////////////////////////////
//
//	API Function:  JM_Initialize
//  Description:   This function Initializes the Job Manager
//	Return:
//			
///////////////////////////////////////////////////////////////////
UInt32 JM_Initialize( char * ptszPath, char * ptszAppName, char * ptszAppVersion, bool fUseJPCallback);


////////////////////////////////////////////////////////////////////
//
//	API Function:  JM_Terminate
//  Description:   This function Terminates the Job Manager
//	Return:
//			
///////////////////////////////////////////////////////////////////
UInt32 JM_Terminate(void);


////////////////////////////////////////////////////////////////////
//
//	API Function:  	JM_GetStatusFile
//  Description:   	This function gets the name of the status file
//	Inputs:			tszStatusFile - pointer to XML status file name
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JM_GetStatusFile( char * tszStatusFile );


////////////////////////////////////////////////////////////////////
//
//	API Function:  	JM_NewJob
//  Description:   	This function requests a new job to start
//	Inputs:			tszJobFile - pointer to XML Job file name
//	Return:			pdwJobID = JobID assigned by Job Manager
//					This JobID is used as a reference in STATUS.XML
//					
//
///////////////////////////////////////////////////////////////////
UInt32 JM_NewJob( char * tszJobFile, UInt32 * pdwJobID );


////////////////////////////////////////////////////////////////////
//
//	API Function:  	JM_PauseJob
//  Description:   	This function Pauses a job or all jobs
//	Inputs:			dwJobID - the JobID of the job to pause
//						0 = Pause all jobs
//						The current operation will be completed first
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JM_PauseJob( UInt32 dwJobID );


////////////////////////////////////////////////////////////////////
//
//	API Function:  	JM_CancelJob
//  Description:   	This function Cancels a job or all jobs
//	Inputs:			dwJobID - the JobID of the job to cancel
//						0 = Cancel all jobs
//						The current operation will be completed first
//
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JM_CancelJob(UInt32 hRobot,  UInt32 dwJobID );


////////////////////////////////////////////////////////////////////
//
//	API Function:  	JM_PromoteJob
//  Description:   	This function Promotes/Demotes a job
//	Inputs:			dwJobID - the JobID of the job to promote/demote
//					nMoveUpDown - number to move (positive=up negative=down)
//	
//					NOTE: This is only possible if the job is not in process
//
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JM_PromoteJob( UInt32 dwJobID, int nMoveUpDown );

////////////////////////////////////////////////////////////////////
//
//	API Function:  	JM_SetLanguage
//  Description:   	This function sets the current language
//	Inputs:			dwLanguage - see Languages defines above
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JM_SetLanguage( UInt32 dwLanguage );

////////////////////////////////////////////////////////////////////
//
//	API Function:  	JM_OpenCloseDrive
//  Description:   	This function opens or closes the specified drive
//	Inputs:			dwDriveID - drive ID for which to get disc information
//					dwOpenOrClose - tells whether to open or close the drive
//								JM_OPEN_DRIVE = 0 (Open the drive tray)
//								JM_CLOSE_DRIVE = 1 = (Close the drive tray)
//					fWaitToReturn - return immediately from call or not
//								0 = return immmediately (before the open/close has occurred)
//								1 = wait until drive is opened or closed until returning
//
//	Return:
//
///////////////////////////////////////////////////////////////////
UInt32 JM_OpenCloseDrive( UInt32 dwDriveID, 
						  UInt32 dwOpenOrClose,
						  bool fWaitToReturn);
    
UInt32 JM_OpenCloseDrive2( UInt32 hRobot, 
                              UInt32 dwCol,
                              UInt32 dwRow,
                              UInt32 dwClose);


UInt32 JM_RobotSystemAction( UInt32 hRobotID, UInt32 dwAction );

UInt32 JM_SetRobotOptions( UInt32 hRobotID, UInt32 dwOption );
UInt32 JM_GetRobotOptions( UInt32 hRobotID,  UInt32 * pdwOption );

UInt32 JM_SetBinSelection(JM_BinSelection * pBinSel);
	
	UInt32 JM_LogString(UInt32 dwJMJobID,char * ptszRobotName, char * pwszLogString, ...);
	
UInt32 JM_LogJobError(UInt32 dwJMJobID, char * ptszRobotName,	UInt32 dwError);
/******************************************************************************
other prototypes
*******************************************************************************/



#ifdef __cplusplus
}
#endif

