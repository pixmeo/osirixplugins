//-----------------------------------------------------------------------------
// AS_Storage.h
// Copyright (c) Corel Corporation or its subsidiaries. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _AS_Storage_H_
#define _AS_Storage_H_

#include "AS_StorageError.h"
#include "AS_StorageTypes.h"

struct AS_Storage
{
	// LogLevelType is a bit-mask for adding logging features
	typedef UInt64 LogLevelType;
	static const LogLevelType LogLevel_Minimum       = (1 << 1);
	// (1 << (2 .. 3)) - Reserved for Modules
	static const LogLevelType LogLevel_StorageDevice = (1 << 4);
	// (1 << (5 .. 7)) - Reserved for Sub-Modules
	static const LogLevelType LogLevel_Volume        = (1 << 8);
	static const LogLevelType LogLevel_StreamFS      = (1 << 9);
	// (1 << (10 .. 11)) - Reserved for Sub-Modules
	static const LogLevelType LogLevel_File          = (1 << 12);
	// (1 << (13 .. 15)) - Reserved for Sub-Modules
	static const LogLevelType LogLevel_Format        = (1 << 16);
	// (1 << (17 .. 19)) - Reserved for Sub-Modules
	// Other miscellaneous modules and common utilities
	static const LogLevelType LogLevel_OSFileIO      = (1 << 20);
	static const LogLevelType LogLevel_Maximum       = 0xffffffffffffffffULL;

	// Driver selections
	typedef UInt32 DriverType;
	// INTERNAL NOTE: Defines from EPX StartMode
	static const DriverType Driver_Any    = 4;  // Recommended: Will use best available if possible, otherwise will use alternate driver type
	static const DriverType Driver_Best   = 1;  // Only use the best for the OS, do not try alternate drivers
	static const DriverType Driver_Pxhelp = 2;  // Windows PXHELP driver (selected by "best" on Windows OSes)
	static const DriverType Driver_Aspi   = 3;  // Win3x, Win9x and WinNT -specific.
	static const DriverType Driver_Spti   = 86; // WinNT-specific
	static const DriverType Driver_Imapi  = 92; // Imapi2 on Vista and XP

	enum Property
	{
		// Debug logging folder path that holds the AS_Storage.log and sonic_px.log files.
		Prop_LogPath     = 1, //     IN: AS_String
		                      //    OUT: Null-terminated UTF-8 sequence of bytes

		// Configuration folder path that holds the StoragePConfig.dcf file.
		Prop_ConfigPath  = 2, //     IN: AS_String
		                      //    OUT: Null-terminated UTF-8 sequence of bytes

		// Maximum debug log file size in bytes (defaults to 10 MB).
		Prop_LogFileSize = 3, // IN/OUT: UInt64

		// Debug log level flags.
		Prop_LogLevel    = 4, // IN/OUT: AS_Storage::LogLevelType

		// Transport filter driver used to communicate with devices.
		Prop_Driver      = 5, // IN/OUT: AS_Storage::DriverType

		// Four-digit AuthorScript engine version.
		Prop_Version     = 6, //    OUT: UInt16[4] array

		// Turn log file wrapping on or off:
		// 0 = Stop logging when file reaches Prop_LogFileSize
		// 1 = Wrap when file reaches Prop_LogFileSize (default)
		Prop_LogWrap     = 7  // IN/OUT: UInt32
	};
};

#ifdef __cplusplus
extern "C"
{
#endif


//-----------------------------------------------------------------------------
// AS_Storage_GetProperty
//
// DESCRIPTION:
// Get a property of the AuthorScript engine as defined by AS_Storage::Property.
//
// RETURN:
// AS_StorageError_None             - ok
// AS_StorageError_BufferOverflow   - if 'bufLen' is not large enough
// AS_StorageError_Fatal            - if the engine could not be started
// AS_StorageError_InvalidParameter - if 'prop' is invalid or is not enabled
//
AS_StorageError AS_API AS_Storage_GetProperty(
	const AS_Storage::Property& prop, // IN:     Property to get (see AS_Storage::Property)
	UInt32 bufLen,                    // IN:     Size of propData buffer
	void* propData,                   // OUT:    Buffer to copy property value into
	UInt32* propSize,                 // OUT:    Size of data returned in propData
	UInt32 propertyIndex,             // IN:     List index of property to return, if applicable
	UInt32 extBufLen,                 // IN:     Size of extPropData buffer, 0 if none
	void* extPropData,                // IN/OUT: Buffer to copy extended property value into, 0 if none
	UInt32* extPropSize);             // OUT:    Size of data returned in extPropData

//-----------------------------------------------------------------------------
// AS_Storage_SetProperty
//
// DESCRIPTION:
// Set a property of the AuthorScript engine as defined by AS_Storage::Property.
//
// RETURN:
// AS_StorageError_None             - ok
// AS_StorageError_DeviceSelected   - if one or more devices are in use (see Prop_Driver)
// AS_StorageError_Fatal            - if the engine could not be started
//                                  - if an internal engine error occurred
// AS_StorageError_FolderNotFound   - if the specified path could not be found
// AS_StorageError_InvalidAccess    - if the configuration path could not be updated
// AS_StorageError_InvalidParameter - if 'prop' is invalid or not enabled
//                                  - if 'propSize' is not large enough
//                                  - if 'propData' is null or invalid
// AS_StorageError_InvalidSequence  - if callbacks are still registered when setting Prop_Driver
//                                    Please unregister callbacks before changing the driver
//                                    (see AS_SetStorageDeviceCallback).
//
AS_StorageError AS_API AS_Storage_SetProperty(
	const AS_Storage::Property& prop, // IN:     Property to set (see AS_Storage::Property)
	UInt32 propSize,                  // IN:     Size of propData buffer
	void* propData,                   // IN:     Buffer holding property value to set
	UInt32 propertyIndex,             // IN:     List index of property to set, if applicable
	UInt32 extBufLen,                 // IN:     Size of extPropData buffer, 0 if none
	void* extPropData);               // IN/OUT: Buffer holding extended property value to set, 0 if none


#ifdef __cplusplus
}
#endif

#endif // _AS_Storage_H_
