//-----------------------------------------------------------------------------
// AS_Format.h
// Copyright (c) Corel Corporation or its subsidiaries. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _AS_FormatH
#define _AS_FormatH

#include "AS_StorageDevice.h"
#include "AS_StorageError.h"
#include "AS_Volume.h"

typedef AS_String AS_URL;
typedef AS_String AS_PlanProject; // XML Project File (Unicode)


// AS_Format allows the creation of known logical formats destined for a
// variety of targets.
struct AS_Format : public AS_Volume
{
	// Properties of AS_Format Objects
	enum Property
	{
		//  IN: Property may only be set
		// OUT: Property may only be obtained
		// I/O: Property may be set and obtained
		Prop_Project          = 0x01, // [NOT IMPLEMENTED] Flattened Layout Object as XML Unicode Text
		Prop_SourceVolume     = 0x02, // I/O: Source volume (AS_Volume) of the AS_Format object
		Prop_VideoFreeBlocks  = 0x04, // OUT: Free space suitable for video (meets rules for alignment and minimum extent size)

		// Multi-Layer Properties
		Prop_Layer_Base      = 0x0100,
		Prop_LayerBlocks     = Prop_Layer_Base + 0x01, // OUT: (UInt32) For multi-layer formats, the number of blocks in a layer (for multi-layer only after AS_Volume_Prepare)
		                                               //      propertyIndex = layer number
		Prop_LogicalLayerBrk = Prop_Layer_Base + 0x02, //  IN: (LogicalLayerBreak) Byte offset into a file where the LB should be.
		                                               //      Call AS_Format_GetLayerBreakRange to get the range of valid breaks.

		// CD-DA Specific Properties
		Prop_Audio_Base            = 0x0200,
		// CD-Text strings are of type wchar_t unless otherwise specified.
		Prop_Audio_MediaCatalogNum = Prop_Audio_Base + 0x01, // I/O: Thirteen byte Media Catalog Number
		Prop_Audio_Title           = Prop_Audio_Base + 0x02, // I/O: String CD-Text Title
		Prop_Audio_Performer       = Prop_Audio_Base + 0x03, // I/O: String CD-Text Performer
		Prop_Audio_Songwriter      = Prop_Audio_Base + 0x04, // I/O: String CD-Text Songwriter
		Prop_Audio_Composer        = Prop_Audio_Base + 0x05, // I/O: String CD-Text Composer
		Prop_Audio_Arranger        = Prop_Audio_Base + 0x06, // I/O: String CD-Text Arranger
		Prop_Audio_Message         = Prop_Audio_Base + 0x07, // I/O: String CD-Text Message
		Prop_Audio_Genre           = Prop_Audio_Base + 0x08, // I/O: String CD-Text Genre
		Prop_Audio_Genre_Code      = Prop_Audio_Base + 0x09, // I/O: String CD-Text Genre Code
		Prop_Audio_NumLanguages    = Prop_Audio_Base + 0x0A, // OUT: (UInt32) Number of languages with CD-Text
		Prop_Audio_Languages       = Prop_Audio_Base + 0x0B, // OUT: (UInt8[]) Array of CD-Text language codes. See CDTextLanguageType.

		// VCD Specific Properties (reserved for future properties)
		Prop_VCD_Base = 0x0300,

		// DVD-V Specific Properties (reserved for future properties)
		Prop_DVD_Base           = 0x0400,
		Prop_DVD_PlaybackRegion = Prop_DVD_Base + 0x01, // I/O: (UInt8) DVD-V regions which are not allowed
		Prop_DVD_EccAligned     = Prop_DVD_Base + 0x02, //  IN: (UInt32) Force ECC alignment of VOB files
		                                                //      0 = Do not align VOB files
		                                                //      1 = Align VOB files on ECC block boundaries
		                                                //      VOB files must be aligned for Qflix Consumer and DVD-Download media.
		                                                //      In all other cases, does not align by default.

		// CSS Specific Properties
		Prop_CSS_Base      = 0x0500,               // For DDP2 Targets (CPR_MAI)
		Prop_CSS_KeySet    = Prop_CSS_Base + 0x01, // IN: (CSSKeyStruct) Set CSS Disc and Title key blocks
		                                           //     Qflix by AS_Format should set the TKB to all zeros
		Prop_CSS_TitleKeys = Prop_CSS_Base + 0x02, // IN: (TitleKeySet)  Set Title keys
		                                           //     Qflix by AS_Format must set at least one key

		// AACS Specific Properties
		Prop_AACS_Base      = 0x0600,                // For Type_DDP30 and Type_CMF20_HD Targets
		Prop_AACS_VolumeID  = Prop_AACS_Base + 0x01, // IN: (AS_String) Volume ID (one per volume)
		Prop_AACS_TitleKey  = Prop_AACS_Base + 0x02, // IN: (AS_String) Title key (may add one or more per volume)
		Prop_AACS_StartPMSN = Prop_AACS_Base + 0x03, // IN: (AS_String) Start of PMSN range
		Prop_AACS_EndPMSN   = Prop_AACS_Base + 0x04, // IN: (AS_String) End of PMSN range

		// DDP/CMF General Properties
		Prop_DDP_Base                  = 0x0700,
		Prop_DDP_MasterID              = Prop_DDP_Base + 0x01, //  IN: (AS_String) Master ID as ASCII characters
		Prop_DDP_NumLayers             = Prop_DDP_Base + 0x02, // I/O: (UInt32) Number of layers on final disc
		Prop_DDP_NumSides              = Prop_DDP_Base + 0x03, // I/O: (UInt32) Number of sides on final disc (1 or 2)
		Prop_DDP_CurrentSide           = Prop_DDP_Base + 0x04, // I/O: (UInt32) Current side of final disc (1 or 2)
		Prop_DDP_TrackPath             = Prop_DDP_Base + 0x05, // I/O: (UInt32) Direction of translation (only valid on dual-layer)
		                                                       //      0 = Opposite Track Path DVD-ROM
		                                                       //      1 = Parallel Track Path DVD-ROM
		Prop_DDP_DiscSize              = Prop_DDP_Base + 0x06, // I/O: (UInt32) Size in cm of disc to be mastered (8 or 12)
		Prop_DDP_StorageMode           = Prop_DDP_Base + 0x07, // I/O: (UInt32) Source Storage Mode
		                                                       //      0 = User data only, 2048 bytes
		                                                       //      1 = Complete 2054 bytes
		                                                       //      6 = Incomplete 2064 bytes (currently not supported)
		                                                       //      7 = Complete 2064 bytes (currently not supported)
		Prop_DDP_Span_AS_StorageDevice = Prop_DDP_Base + 0x08, //  IN: AS_StorageDevice to span to 2nd DLT device for 2nd layer
		// NOTE: Prop_DDP_ChecksumFile and Prop_DDP_DiscTag are mutually exclusive.
		//       If both are set, the last one set will be used.
		Prop_DDP_ChecksumFile          = Prop_DDP_Base + 0x09, // I/O: (UInt32) Whether or not to write ImageIntegrity Checksum File
		                                                       //      0 = Do not write checksum file
		                                                       //      1 = Write checksum file (default)
		Prop_DDP_InputImage            = Prop_DDP_Base + 0x0A, //  IN: (AS_String) Full path of existing image file to be used in DDP (or CMF) file set.
		                                                       //      This is optional and is only to be used when an image already exists that the client
		                                                       //      wants to create a DDP (or CMF) set from. It is assumed to be only user data (2048 byte/sector).
		// NOTE: Prop_DDP_DiscTag and Prop_DDP_ChecksumFile are mutually exclusive.
		//       If both are set, the last one set will be used.
		Prop_DDP_DiscTag               = Prop_DDP_Base + 0x0B, // [CURRENTLY NOT SUPPORTED: RESERVED FOR FUTURE USE]
		                                                       //  IN: (DiscTagProperties) Write DiscTag using the provided information
		// NOTE: Prop_DDP_Signature and Prop_DDP_DiscTag are mutually exclusive.
		//       If both are set, the last one set will be used.
		Prop_DDP_Signature             = Prop_DDP_Base + 0x0C, //  IN: (UInt32) Whether or not to write Image Signature file
		                                                       //      0 = Do not write signature file
		                                                       //      1 = Write signature file (default)

		// DDP2 Specific Properties
		Prop_DDP2_Base       = 0x0800,
		Prop_DDP2_SscrStatus = Prop_DDP2_Base + 0x01, // I/O: (UInt32) Security Scrambling Status
		                                              //      0 = The data for the disc contains no security scrambling. The final disc will not be scrambled for security.
		                                              //      1 = The data for the disc contains no security scrambling. The final disc will be scrambled for security.
		                                              //      2 = The data for the disc contains security scrambling. The final disc will be scrambled for security. CURRENTLY NOT SUPPORTED.
		                                              //      3 = The data for the disc contains no security scrambling. The security scrambling keys are read from a floppy disk. Format the floppy according to CSS Site Guide Book. The final disc will be scrambled for security.

		// DDP3 Specific Properties (also applies to HD CMF)
		Prop_DDP3_Base               = 0x0900,                // DDP3 Properties
		Prop_DDP3_Title              = Prop_DDP3_Base + 0x01, // IN: (AS_String) Title of the disc image contents
		Prop_DDP3_Author             = Prop_DDP3_Base + 0x02, // IN: (AS_String) Name and version of the authoring system used to create the disc image
		Prop_DDP3_CopyrightNotice    = Prop_DDP3_Base + 0x03, // IN: (AS_String) Copyright notice for the disc image contents
		Prop_DDP3_Abstract           = Prop_DDP3_Base + 0x04, // IN: (AS_String) Description of the disc image contents
		Prop_DDP3_DiscID             = Prop_DDP3_Base + 0x05, // IN: (AS_String) GUID to uniquely identify the disc
		Prop_DDP3_MediaType          = Prop_DDP3_Base + 0x06, // IN: (UInt32) Type of disc being described by the DDP file set
		                                                      //     0 = HD DVD-ROM (default)
		                                                      //     1 = HD DVD-ROM Twin Format - indicates that layer 0 will contain a Standard Density DVD image
		                                                      //         and current DDP set is single layer that will go on layer 1 of destination disc
		                                                      //     2 = 3X-SPEED DVD-ROM
		Prop_DDP3_CopyProtectionInfo = Prop_DDP3_Base + 0x07, // [DEPRECATED]

		// BDCMF Specific Properties
		Prop_BDCMF_Base              = 0x0A00,                 // BDCMF Properties
		Prop_BDCMF_BD_Type           = Prop_BDCMF_Base + 0x01, // IN: (UInt32) BD Type
		                                                       //     0 = BD (default)
		                                                       //     1 = BD9 (BD content on DL DVD-ROM)
		Prop_BDCMF_HybridType        = Prop_BDCMF_Base + 0x02, // IN: (UInt32) Hybrid Type
		                                                       //     0 = No hybrid (default)
		                                                       //     1 = BD with CD hybrid
		                                                       //     2 = BD with DVD hybrid
		Prop_BDCMF_ContentCategory   = Prop_BDCMF_Base + 0x03, // IN: (UInt32) Category Type
		                                                       //     0 = BD-ROM Movie Media (default)
		                                                       //     1 = BD-ROM Movie Media with BD Data
		                                                       //     2 = BD-ROM Data Media
		Prop_BDCMF_AuthorsNote       = Prop_BDCMF_Base + 0x04, // IN: (AS_String) Optional note from Authoring Studio to Replication Facility (4096 characters max)
		Prop_BDCMF_BDI_Usage         = Prop_BDCMF_Base + 0x05, // IN: (UInt32) Use of Basic Disc Information (BDI)
		                                                       //     0 = None (default)
		                                                       //     1 = Use Basic Disc Information
		Prop_BDCMF_PMSN_Usage        = Prop_BDCMF_Base + 0x06, // IN: (UInt32) Use of Pre-recorded Media Serial Number (PMSN)
		                                                       //     0 = None (default)
		                                                       //     1 = Use conventional PMSN
		                                                       //     2 = Use Un-Guessable PMSN
		Prop_BDCMF_BCAID_SN_Usage    = Prop_BDCMF_Base + 0x07, // IN: (UInt32) Use of BCAID for Serial Number and data length
		                                                       //     0 = None (default)
		                                                       //     1 = USE16
		                                                       //     2 = USE32
		Prop_BDCMF_BCAID_UD_Usage    = Prop_BDCMF_Base + 0x08, // IN: (UInt32) Use of of BCAID for User Data and data length
		                                                       //     0 = None (default)
		                                                       //     1 = USE16
		                                                       //     2 = USE32
		Prop_BDCMF_BCA_Usage         = Prop_BDCMF_Base + 0x09, // IN: (UInt32) Use of BCA on BD9 media
		                                                       //     0 = None (default)
		                                                       //     1 = Use BCA
		Prop_BDCMF_DiscInfoNote      = Prop_BDCMF_Base + 0x0A, // IN: (AS_String) Optional additional disc related information (4096 characters max)
		Prop_BDCMF_TitleName         = Prop_BDCMF_Base + 0x0B, // IN: (AS_String) The title of the disc, such as movie title (256 characters max)
		Prop_BDCMF_CopyrightNotice   = Prop_BDCMF_Base + 0x0C, // IN: (AS_String) Copyright notice
		Prop_BDCMF_BD_J_Usage        = Prop_BDCMF_Base + 0x0D, // IN: (UInt32) Whether or not content on the media uses BD-J
		                                                       //     0 = does not use BD-J (default)
		                                                       //     1 = uses BD-J
		Prop_BDCMF_BD_Live_Usage     = Prop_BDCMF_Base + 0x0E, // IN: (UInt32) Whether or not content on the media uses BD-Live
		                                                       //     0 = does not use BD-Live (default)
		                                                       //     1 = uses BD-Live
		Prop_BDCMF_Region            = Prop_BDCMF_Base + 0x0F, // IN: (UInt32) Region control status
		                                                       //     0 = Allowed (default) - all of the disc can be played back
		                                                       //     1 = Limited - a part of the disc can be played back
		                                                       //     2 = Prohibited - entire disc can't be played back
		                                                       //     3 = Not applicable - authoring studio can't set Region
		                                                       //     PropertyIndex parameter indicates which Region
		                                                       //     0 = Region A (default)
		                                                       //     1 = Region B
		                                                       //     2 = Region C
		                                                       //     These regions must all be set or none. By setting one of them (i.e., A),
		                                                       //     the others (i.e., B and C) will all be all be set to the default (Allowed).
		Prop_BDCMF_ContentOwnerNote  = Prop_BDCMF_Base + 0x10, // IN: (AS_String) Optional information from the Content Owner (4096 characters max)
		Prop_BDCMF_TitleInfoNote     = Prop_BDCMF_Base + 0x11, // IN: (AS_String) Optional Title related information. Authoring Studio can use
		                                                       //     this space for a message to Disc Replication Facility (4096 characters max)
		Prop_BDCMF_AACS_Usage        = Prop_BDCMF_Base + 0x12, // IN: (UInt32) Use AACS on media
		                                                       //     0 = AACS is not used on media
		                                                       //     1 = AACS is used on media (default)
		Prop_BDCMF_BDPlus_Usage      = Prop_BDCMF_Base + 0x13, // IN: (UInt32) Use BD+ on media
		                                                       //     0 = BD+ is not used on media (default)
		                                                       //     1 = BD+ is used on media
		Prop_BDCMF_SequenceKey_Usage = Prop_BDCMF_Base + 0x14, // IN: (UInt32) Use Sequence Key
		                                                       //     0 = Sequence Key not used (default)
		                                                       //     1 = Sequence Key is used
		Prop_BDCMF_SRM_DTCP_Usage    = Prop_BDCMF_Base + 0x15, // IN: (UInt32) Use SRM for DTCP
		                                                       //     0 = SRM for DTCP not used (default)
		                                                       //     1 = SRM for DTCP is used
		Prop_BDCMF_SRM_HDCP_Usage    = Prop_BDCMF_Base + 0x16, // IN: (UInt32) Use SRM for HDCP
		                                                       //     0 = SRM for HDCP not used (default)
		                                                       //     1 = SRM for HDCP is used
		Prop_BDCMF_FacilityName      = Prop_BDCMF_Base + 0x17, // IN: (AS_String) Name of the facility where the BDCMF is generated (256 characters max)
		Prop_BDCMF_FacilityLocation  = Prop_BDCMF_Base + 0x18, // IN: (AS_String) Location of the facility where the BDCMF is generated (256 characters max)
		Prop_BDCMF_WorkID            = Prop_BDCMF_Base + 0x19, // IN: (AS_String) Optional work ID of the project (256 characters max)
		Prop_BDCMF_Operator          = Prop_BDCMF_Base + 0x1A, // IN: (AS_String) Optional name of the operator performing the process (256 characters max)
		Prop_BDCMF_ToolName          = Prop_BDCMF_Base + 0x1B, // IN: (AS_String) Optional name of the tool performing the process (256 characters max)
		Prop_BDCMF_ToolVersion       = Prop_BDCMF_Base + 0x1C, // IN: (AS_String) Optional version of the tool performing the process (256 characters max)
		Prop_BDCMF_ProcessNote       = Prop_BDCMF_Base + 0x1D, // IN: (AS_String) Optional additional process information (4096 characters max)
		Prop_BDCMF_PlayingTimeInfo   = Prop_BDCMF_Base + 0x1E, // IN: (PlayingTimeInfo) Playing time of each codec used
		                                                       //     This property must be called once for each codec.
		Prop_BDCMF_CpsUnitInfo       = Prop_BDCMF_Base + 0x1F, // IN: (CpsUnitInfo) Filename, encryption usage and CPS unit number for each M2TS and SSIF file.
		                                                       //     If not set then defaults all M2TS and SSIF files as "Encrypted" with CPS unit number one.
		Prop_BDCMF_UseBusEncryption  = Prop_BDCMF_Base + 0x20, // IN: (UInt32) Turn the Bus Encryption Flag (BEF) on (1 = default) or off (0)
		Prop_BDCMF_VISAN             = Prop_BDCMF_Base + 0x21, // IN: (AS_String) Optional VISAN number of the disc image contained in the CMF
		Prop_BDCMF_Revision          = Prop_BDCMF_Base + 0x22, // IN: (AS_String) Optional revision number of the CMF (256 characters max)
		Prop_BDCMF_DiscNumber        = Prop_BDCMF_Base + 0x23, // IN: (AS_String) Optional disc number for the disc image contained in the CMF (256 characters max)
		Prop_BDCMF_PrivateInfo1      = Prop_BDCMF_Base + 0x24, // IN: (AS_String) Optional private information (256 characters max)
		Prop_BDCMF_PrivateInfo2      = Prop_BDCMF_Base + 0x25, // IN: (AS_String) Optional private information (256 characters max)
		Prop_BDCMF_Distributor       = Prop_BDCMF_Base + 0x26, // IN: (AS_String) Optional name or identifier of the Distributor (256 characters max)
		Prop_BDCMF_ContentOwner      = Prop_BDCMF_Base + 0x27, // IN: (AS_String) Optional name or identifier of the Content Owner (256 characters max)
		Prop_BDCMF_BD3D_Usage        = Prop_BDCMF_Base + 0x28, // IN: (UInt32) BD-3D Usage
		                                                       //     0 = None             - 2D using M2TS (default)
		                                                       //     1 = Use with SSIF    - 3D using SSIF (if SSIF folder is present this will always be set)
		                                                       //     2 = Use without SSIF - 3D using M2TS
		Prop_BDCMF_SSIFSpecificArea  = Prop_BDCMF_Base + 0x29, // IN: (SSIFSpecificArea) Set once for each identical extent in a SSIF file

		// DVD+VR Specific Properties
		Prop_PlusVR_Base            = 0x0B00,                  // DVD+VR Properties
		Prop_PlusVR_RemappedFileLBA = Prop_PlusVR_Base + 0x01, // OUT: (UInt32) Sector address of where file is remapped to on an un-finalized DVD+VR disc
		                                                       //      Parameters to AS_Format_GetProperty shall be set as follows:
		                                                       //      PropertyIndex - set to zero, ignored
		                                                       //      extbufLen     - sizeof(AS_String)
		                                                       //      extPropData   - pointer to AS_String containing the full path of the file
		                                                       //      extpropSize   - NULL, ignored
		                                                       //
		                                                       //      This should only be called after AS_Volume_Prepare and before AS_Volume_Flush
		                                                       //      and is used for un-finalized DVD+VR format written to DVD+R to generate IFO file data.

		// Qflix Specific Properties
		Prop_MD_Base                  = 0x1000,              // Qflix Properties
		Prop_MD_TrailerReplaceInfo    = Prop_MD_Base + 0x01, //  IN: (TrailerReplaceInfo) Specifies source path, optional index and additional source folder path for title (trailer) replacement
		Prop_MD_TargetStartSector     = Prop_MD_Base + 0x02, // I/O: (UInt32) Logical block offset to move layout on target
		Prop_MD_Protection_Type       = Prop_MD_Base + 0x03, //  IN: (MDProtectionTypes) Bitfield specifying copy protection type for targets
		Prop_MD_SourceProtectionIndex = Prop_MD_Base + 0x04, // [DEPRECATED] IN: (UInt32) Source protection index
		Prop_MD_SourceAESKey          = Prop_MD_Base + 0x05, // [DEPRECATED] IN: 128-bit AES key which the source is encrypted with (VOBs only)
		Prop_MD_SourceProtection_Type = Prop_MD_Base + 0x06, // [NOT IMPLEMENTED] (MDSrcProtectionTypes) Bitfield specifying copy protection type for sources
	};

	// Volume state returned from GetProperty
	typedef UInt32 State;
	static const State IsDirty      = (1 << 0);
	static const State IsAppendable = (1 << 1);

	// Logical Layer Break passed to SetProperty(Prop_LogicalLayerBrk)
	// specifies a file and byte offset into file where the layer break will be
	struct LogicalLayerBreak
	{
		AS_String fileName; // File on destination that will span the layer break
		UInt64 byteOffset;  // Byte offset into file where the layer break will occur
	};

	// Title Key set
	struct TitleKeySet
	{
		SInt32 titleIndex; // DVD-V Title number (01-99)
		UInt8 keyInfo[5];  // Encrypted Title Key
		UInt8 uKeyInfo[5]; // Unencrypted Title Key
	};

	// TrailerReplaceInfo passed to SetProperty(Prop_MD_TrailerReplaceInfo)
	// specifies a specific VTS title set (trailer) and the source folder path of the replacement trailer set.
	// If no replacement is needed, the value of replaceIndex = 0.
	// The value of replaceIndex = -1 for last title, -2 for 2nd from last, etc.
	struct TrailerReplaceInfo
	{
		SInt32 replaceIndex;
		AS_String replacementFolder;
	};

	// CSS Information
	struct CSSKeyStruct
	{
		UInt8 ACC;            // Lower 5 bits are ACC
		UInt8* discKeyBlock;  // Must be 2048 bytes
		UInt8* titleKeyBlock; // Must be 2048 bytes
	};

	// DiscTagProperties passed to SetProperty (see Prop_DDP_DiscTag).
	// This is for using the DiscTag to aid in preserving the integrity of the
	// DDP/CMF file set throughout the process from authoring to replication.
	struct DiscTagProperties
	{
		AS_String owner;      // Typically the name of the studio or publisher (can be blank)
		AS_String titleName;  // Name of the title as specified by the publisher
		AS_String catalog;    // Unique reference identifier as specified by the publisher to reference the job
		AS_String customer;   // May be the same as the owner or different if ordered by 3rd party (can be blank)
		AS_String site;       // Site licensee from product dongle to identify author, loader, or builder of layer files
		AS_String jobRelated; // Any job related data you wish to include
		DateTime expiration;  // Expiration date of content as specified by publisher
	};

	// Specifies the type of codec (see PlayingTimeInfo).
	typedef UInt32 CodecType;
	static const CodecType Codec_MPEG2            = 0x00;
	static const CodecType Codec_AVC              = 0x01;
	static const CodecType Codec_VC1              = 0x02;
	static const CodecType Codec_LPCM             = 0x03;
	static const CodecType Codec_AC3              = 0x04;
	static const CodecType Codec_DTS              = 0x05;
	static const CodecType Codec_DolbyLossless    = 0x06;
	static const CodecType Codec_DolbyDigitalPlus = 0x07;
	static const CodecType Codec_DTS_HD           = 0x08;
	static const CodecType Codec_DTS_HD_XLL       = 0x09;
	static const CodecType Codec_DRA              = 0x0A;
	static const CodecType Codec_DRA_Extension    = 0x0B;
	static const CodecType Codec_MVC              = 0x0C;

	// PlayingTimeInfo passed to SetProperty (see Prop_BDCMF_PlayingTimeInfo).
	// This indicates the duration of time used for the codec indicated and
	// should be set for each codec used.
	struct PlayingTimeInfo
	{
		CodecType codec; // Type of codec
		UInt32 hours;    // Hours
		UInt32 minutes;  // Minutes
		UInt32 seconds;  // Seconds
		UInt32 mseconds; // Milliseconds
	};

	// CpsUnitInfo is passed to SetProperty (see Prop_BDCMF_CpsUnitInfo) and
	// indicates the CPS unit number and encryption usage for each M2TS and
	// SSIF file in the BDCMF set. The caller should set one CpsUnitInfo struct
	// for each M2TS and SSIF file. If no files are assigned a CPS number then
	// all M2TS and SSIF files will default to encryption using unit number one.
	struct CpsUnitInfo
	{
		AS_String fileName;   // Full path of M2TS or SSIF file on destination volume
		UInt32 cpsUnitNumber; // CPS unit number corresponding to this file
		bool encrypted;       // Whether or not this file shall be encrypted on final disc
	};

	// SSIFSpecificArea is passed to SetProperty (see Prop_BDCMF_SSIFSpecificArea)
	// to indicate any identical extents in a SSIF file. See section L.3.3.4 of
	// the version 1.21 BDCMF specification. This may be set more than once for
	// the same 'ssifFileName' to define multiple extents.
	struct SSIFSpecificArea
	{
		AS_String ssifFileName; // Full path of SSIF file on destination volume
		UInt32 m2tsSpecificLBA; // Sector offset into the SSIF file of the start of the M2TS-Specific area
		UInt32 ssifSpecificLBA; // Sector offset into the SSIF file of the start of the SSIF-Specific area
		UInt32 sectors;         // Size of the area in sectors
	};

	// CD-Text language support. Used as ExtendedInfo (see AS_Format_(Get/Set)Property)
	typedef UInt32 CDTextLanguageType;
	static const CDTextLanguageType CDTextLangGerman   = 0x08;
	static const CDTextLanguageType CDTextLangEnglish  = 0x09;
	static const CDTextLanguageType CDTextLangSpanish  = 0x0a;
	static const CDTextLanguageType CDTextLangFrench   = 0x0f;
	static const CDTextLanguageType CDTextLangItalian  = 0x15;
	static const CDTextLanguageType CDTextLangDutch    = 0x1d;
	static const CDTextLanguageType CDTextLangRussian  = 0x56;
	static const CDTextLanguageType CDTextLangKorean   = 0x65;
	static const CDTextLanguageType CDTextLangJapanese = 0x69;
	static const CDTextLanguageType CDTextLangChinese  = 0x75;

	// Supported destination protection types
	typedef UInt32 MDProtectionTypes;
	static const MDProtectionTypes MD_TargetProtection_CSS = (1 << 1); // Target protection only

	// Supported source protection types
	typedef UInt32 MDSrcProtectionTypes;
	static const MDSrcProtectionTypes MD_SrcProtection_ISO_SecureData = (1 << 8); // Source protection only
};


#ifdef __cplusplus
extern "C"
{
#endif

//
// Basic Layout API functions
//

//-----------------------------------------------------------------------------
// AS_StorageDevice_OpenFormat
//
// DESCRIPTION:
// Opens an AS_Format object, creating a data structure in RAM that is ready
// to receive file structure information from the media in the specified
// device. The volume's logical format (see AS_Volume_FS_Type) is output with
// the parameter kind (if the media is blank the kind will be
// AS_Volume::FS_None). A reference (AS_Format struct) is output with format,
// which may be used to refer to the format in subsequent calls. AS_Format
// inherits from AS_Volume, so it can also be used in functions that take an
// AS_Volume IN parameter.
//
// A callback with which the AuthorScript engine will report on the progress of
// the operation is specified with callback. The parameter userData allows the
// host application to specify a pointer to a memory location that will be passed
// back whenever AuthorScript calls the callback.
//
// NOTES:
// An error (AS_Error_NotSupported = 38) will result if the format of the volume
// is not supported by your version of AuthorScript Imaging. Please contact your
// Corel representative if you have any questions about which formats are covered.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if the flags are not defined, or other parameter contains invalid value
//  AS_StorageError_DeviceNotReady   - if there is no media recognized in device
//
AS_StorageError AS_API AS_StorageDevice_OpenFormat(
	const AS_StorageDevice& device,   //  IN:  A reference to the AS_StorageDevice struct specifying the device containing the volume to open.
	AS_Volume::FS_Type& kind,         // OUT: A reference to the AS_Volume::FS_Type object that is to be filled in with the kind of volume detected.
	AS_Volume::InfoCallback callback, //  IN:  progress callback function
	void* userData,                   //  IN:  progress callback userData
	AS_Format& format);               // OUT: AS_Format reference

//-----------------------------------------------------------------------------
// AS_Format_Close
//
// DESCRIPTION:
// Releases the specified AS_Format object and all associated memory.
//
// NOTES:
// To update changes on media before releasing the AS_Format, first call AS_Volume_Flush.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if the flags are not defined.
//
AS_StorageError AS_API AS_Format_Close(
	AS_Format& layout); // IN: layout reference

//-----------------------------------------------------------------------------
// AS_Format_Create
//
// DESCRIPTION:
// Mounts the specified AS_Format and formats it in the FS_Type (ISO, UDF 1.02,
// UDF 2.0, etc.) specified with the parameter fsKind, and the Format_Type
// (Type_VCD, Type_DVD, Type_BDMV, etc.) specified with the parameter
// formatKind. For some Format_Type's the fsKind parameter is ignored and the
// proper FS_Type for that Format_Type is used. A name for the newly-formatted
// AS_Format is specified with name. Limitations, if any, on writing to the
// formatted AS_Format are specified with access; for details see
// AS_Volume::AccessFlag.
//
// A callback with which the AuthorScript engine will report on the progress
// of the operation is specified with callback. The parameter userData allows
// the host application to specify a pointer to a memory location that will be
// passed back whenever AuthorScript calls the callback.
//
// This function will modify the media in preparation for writing in the following cases:
//  - for AS_Volume::Type_BDMV and AS_Volume::Type_BDAV: 
//     - blank DVD-R, DVD-R9, DVD+R and DVD+R9: reserves track for file system metadata 
//     - BDR: reserves tracks on media for file system metadata
//	   - blank, unformatted BDRE media: performs physical format of media
//
// NOTES:
//       An error will result if kind specifies an unsupported AS_Format type.
//       To determine if the media is blank before formatting, see AS_StorageDevice_GetDeviceProperty.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if the flags are not defined, or other parameter contains an invalid value
//  AS_StorageError_InvalidAccess    - results if more than one flag is passed for AccessFlag
//  AS_StorageError_InvalidOperation - results if volume has already been mounted
//  AS_StorageError_Fatal            - if filesystem cannot be formatted
//
AS_StorageError AS_API AS_Format_Create(
	const AS_Format& format,                  // IN: reference to AS_Format handle
	const AS_Volume::FS_Type& fsKind,         // IN: kind of file system to write
	const AS_Volume::Format_Type& formatKind, // IN: kind of format desired
	const AS_File::Path & name,               // IN: Name to write as volume label
	const AS_Volume::AccessFlag & access,     // IN: must be either Mastering or RTTD
	AS_Volume::InfoCallback callback,         // IN: progress callback function
	void* userData);                          // IN: progress callback userData

//-----------------------------------------------------------------------------
// AS_Format_GetProperty
//
// DESCRIPTION:
// Retrieves the value of a property of the specified AS_Format. The parameter prop indicates the
// property (format, state, name, block size, free blocks, date modified, date created, etc.)
// for which to retrieve the current value. The value is output to a buffer pointed to with propData,
// the size of which is specified with bufLen. The actual size of the data written to the buffer
// is output with propSize.
//
// The extended optional parameters are provided for additional property data to be retrieved.
// If the extended info is a list, then the value of property prop for index PropertyIndex
// is provided in extpropData, the size of which is specified with extpropSize.
// If PropertyIndex = 0xffffffff, the whole list is written to extpropData.
//
// If extended info is not a list of items, then PropertyIndex value is ignored.
//
// NOTES:
//       Some properties require AS_Format to be formatted or mounted before being available to query their value.
//       Not all properties support additional property information.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if the flags are not defined or if the property cannot be retrieved
//  AS_StorageError_BufferOverflow   - if the provided buffer length (bufLen) is less than required for this property
//  AS_StorageError_InvalidOperation - if the property cannot be obtained in the current volume state
//
AS_StorageError AS_API AS_Format_GetProperty(
	const AS_Format& format,         //  IN: volume to get property on
	const AS_Format::Property& prop, //  IN: which property to get (see AS_Format::Prop_...)
	UInt32 bufLen,                   //  IN: size available in propData buffer
	void* propData,                  // OUT: buffer to copy property value into
	UInt32* propSize,                // OUT: size of data returned in propData
	UInt32 PropertyIndex=0,          //  IN: index of list of property returned
	UInt32 extbufLen=0,              //  IN: size available in extpropData buffer
	void*  extpropData=0,            // I/O: extended buffer to copy property value into
	UInt32* extpropSize=0);          // OUT: size of data returned in extpropData

//-----------------------------------------------------------------------------
// AS_Format_SetProperty
//
// DESCRIPTION:
// Sets the value of a property of the specified AS_Format. The parameter prop indicates the property
// (e.g. name, date modified, date created, path delimiter) for which the value is to be set.
// The value itself is given in the buffer pointed to with propData, the size of which is specified with propSize.
//
// The extended optional parameters are provided for additional property data to be set.
// If the extended info is a list, then the value of property prop for index PropertyIndex
// is given in extpropData, the size of which is specified with extpropSize.
// If PropertyIndex = 0xffffffff, the whole list is set from extpropData.
//
// If extended info is not a list of items, then PropertyIndex value is ignored.
//
//
// NOTES:
//       All properties require volume to be formatted or mounted before being available to set their value.
//       Not all properties support additional property information.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if the flags are not defined.
//  AS_StorageError_InvalidOperation - if the AS_Format has not been formatted/mounted
//  AS_StorageError_BufferOverflow   - if the provided buffer length (propSize) is less than required for this property
//  AS_StorageError_InvalidAccess    - if the AS_Format's AccessFlag was read-only
//
AS_StorageError AS_API AS_Format_SetProperty(
	const AS_Format& layout,         //  IN: volume to set property on
	const AS_Format::Property& prop, //  IN: which property to set (see AS_Volume::Prop_...)
	UInt32 propSize,                 //  IN: size of data in propData buffer
	void* propData,                  //  IN: property data
	UInt32 PropertyIndex=0,          //  IN:  index of list of property to set
	UInt32 extpropSize=0,            //  IN: size available in extpropData buffer
	void*  extpropData=0);           // I/O: extended buffer to copy property value into


//-----------------------------------------------------------------------------
// AS_Format_GetLayerBreakRange
//
// DESCRIPTION:
// Finds valid range of layer breaks for the specified AS_Format reference.
// Specifies the minimum and maximum valid layer breaks by filename and offset
// into the file.
// The values are to help the client determine what values can be used when
// setting the property AS_Format::Prop_LogicalLayerBrk.
//
// NOTES:
//       applies to Type_DVD and Type_HDDVD
//       should be called after adding all files, and before calling
//       AS_Volume_Prepare() or AS_Volume_Flush()
//
// RETURN:
//  AS_StorageError_None               - ok
//  AS_StorageError_InvalidParameter   - invalid AS_Format object passed in
//  AS_StorageError_InvalidOperation   - if the AS_Format has not been
//                                       formatted/mounted or the AS_Format is
//                                       not Type_DVD or Type_HDDVD
//  AS_StorageError_InvalidAccess      - if the AS_Format's AccessFlag was read-only
AS_StorageError AS_API AS_Format_GetLayerBreakRange(
	const AS_Format& format,            //  IN: reference to AS_Format handle
	AS_File::Path& lowerLimitFilePath,  // OUT: full path of lower limit file
	UInt32& lowerLimitByteOffset,       // OUT: byte offset into lowerLimitFilePath
	AS_File::Path& upperLimitFilePath,  // OUT: full path of upper limit file
	UInt32& upperLimitByteOffset);      // OUT: byte offset into upperLimitFilePath

//
// Get/Set Layout XML
//
// Create a new Format from an XML Project (XML file provides target selection)
// NOTE: Not currently implemented.
AS_StorageError AS_API AS_OpenFormatProject(
	const AS_PlanProject& project, //  IN: project text
	AS_Format& layout);            // OUT: layout reference

// Set Properties for Format from an XML Project
AS_StorageError AS_API AS_Format_SetProjectProperties(
	const AS_Format& layout,            // IN: layout reference
	const AS_PlanProject& projectInfo); // IN: project text

// Save current Format to an XML Project
// NOTE: Not currently implemented.
AS_StorageError AS_API AS_Format_SaveProject(
	const AS_Format& layout,      // IN: layout reference
	AS_PlanProject& projectInfo); // IN: project text


#ifdef __cplusplus
}
#endif
#endif //_AS_FormatH
