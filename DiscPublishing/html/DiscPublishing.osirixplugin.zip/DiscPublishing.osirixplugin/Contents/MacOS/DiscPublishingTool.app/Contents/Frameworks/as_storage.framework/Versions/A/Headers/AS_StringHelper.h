//-----------------------------------------------------------------------------
// AS_StringHelper.h
// Copyright (c) Rovi Corporation or its subsidiaries. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef __AS_StringHelper_h__
#define __AS_StringHelper_h__

#include "AS_StorageTypes.h"

// Client side string helper classes //////////////////////////////////////////

// AS_StringX may never be used as an OUT parameter. It is meant as a
// convenience class for IN data only.
template<class X, AS_String::Type Y>
struct AS_StringX : AS_String
{
	AS_StringX()
	{
		init();
	}
	AS_StringX(size_t count) : s(count, 0)
	{
		init();
	}
	AS_StringX(const X* string) : s(string)
	{
		init();
	}
	AS_StringX(const std::basic_string<X>& string) : s(string)
	{
		init();
	}
	AS_StringX(const AS_StringX& string) : s(string.s)
	{
		init();
	}

	AS_StringX& operator =(const std::basic_string<X>& string)
	{
		s = string;
		init();
		return *this;
	}
	AS_StringX& operator =(const AS_StringX& string)
	{
		s = string.s;
		init();
		return *this;
	}

	operator const X* () const {return s.c_str();}
	operator const std::basic_string<X>& () const {return s;}

private:
	void init()
	{
		type = Y;
		size = s.size() + 1;
		data = const_cast<X*>(s.c_str());
	}
	std::basic_string<X> s;
};

// Please see the important note for the AS_StringX class above. These helper
// classes may never be used as OUT parameters.
typedef AS_StringX<char, AS_String::Type_ASCII> AS_StringA; // ASCII string (local encoding)
typedef AS_StringX<unsigned char, AS_String::Type_UTF8> AS_String8; // UTF8 string
typedef AS_StringX<wchar_t, AS_String::Type_Wide> AS_StringW; // wide string


// Client side string helper methods //////////////////////////////////////////

//-----------------------------------------------------------------------------
// InitAS_String
//
// DESCRIPTION:
// Initializes an AS_String object as an empty string of the given
// AS_String::Type.
//
// NOTES:
// This method is not to be used with the AS_StringX class due to the nature
// of its operation. It is intended for plain AS_String objects only.
//
inline void InitAS_String(const AS_String::Type& type, AS_String& str)
{
	str.type = type;
	str.size = 0;
	str.data = 0;
}

#endif //__AS_StringHelper_h__
