//-----------------------------------------------------------------------------
// AS_AudioFile.h
// Copyright (c) Corel Corporation or its subsidiaries. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _AS_AudioFileH
#define _AS_AudioFileH

#include "AS_Audio.h"
#include "AS_StorageError.h"
#include "AS_StorageTypes.h"


struct AS_AudioFile
{
	typedef UInt32 Handle;

	enum Property
	{
		// General Properties

		// RawSize is the size in bytes of the uncompressed audio data expressed as
		// PCM CD-Audio. It is *not* rounded up to the nearest CD-DA sector size (2352).
		Prop_RawSize       = 0,  // OUT: (UInt64) Estimated size depending on source format (VBR, etc.).
		Prop_RawSize_Exact = 1,  // OUT: (UInt64) Exact size (may take longer for VBR-type files).

		// DRM Specific
		Prop_BurnCount     = 2,  // OUT: (SInt32) Burn count of DRM file, -1 if not protected or unlimited.
		Prop_DRMStatus     = 3   // OUT: (UInt32) DRM status of file, non-zero if DRM, zero otherwise.
	};
};


#ifdef __cplusplus
extern "C"
{
#endif

//-----------------------------------------------------------------------------
// AudioFile API Functions
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// AS_Open_AudioFile
//
// DESCRIPTION:
// Open an AS_AudioFile::Handle for the file specified by the given path.
//
// RETURN:
//  AS_StorageError_None              - ok
//  AS_StorageError_NotInitialized    - if the audio API could not be initialized
//  AS_StorageError_DRM_InvalidAccess - if the file is DRM and a debugger is detected
//  AS_StorageError_DRM_NoLicense     - if the file is DRM and no license is found
//  AS_StorageError_DRM_NoWMAReader   - if the DRM stub library is not present for WMA DRM
//  AS_StorageError_FileNotFound      - if the file could not be found
//  AS_StorageError_FileOpenFailed    - if the file could not be opened
//
AS_StorageError AS_API AS_Open_AudioFile(
	const AS_String& path,         // IN: full path to file
	AS_AudioFile::Handle& handle,  // OUT: file handle
	UInt32 reserved = 0,           // IN: reserved
	UInt32 reserved1 = 0);         // IN: reserved

//-----------------------------------------------------------------------------
// AS_AudioFile_GetProperty
//
// DESCRIPTION:
// Get properties from the file represented by the given AS_AudioFile::Handle.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_NotInitialized   - if the audio API could not be initialized
//  AS_StorageError_BufferOverflow   - if 'bufferSize' is not large enough
//  AS_StorageError_InvalidHandle    - if 'handle' is invalid
//  AS_StorageError_InvalidParameter - if one or more of the parameters are incorrect
//
AS_StorageError AS_API AS_AudioFile_GetProperty(
	const AS_AudioFile::Handle& handle,  // IN: file handle to get property from
	AS_AudioFile::Property prop,         // IN: property requested
	UInt32 bufferSize,                   // IN: size of the property buffer in bytes
	void* propertyBuffer,                // OUT: buffer to hold the requested property data.
	UInt32* retDataSize,                 // OUT: actual amount (size) used of the output buffer
	UInt32 extPropertyIndex = 0,         // IN (Optional): index of extended property - only used for properties which are lists
	UInt32 extBufferSize = 0,            // IN (Optional): size in bytes of the extended buffer
	void* extPropertyBuffer = 0,         // IN/OUT (Optional): extended buffer to hold the requested extended property data
	UInt32* extRetDataSize = 0);         // OUT (Optional): actual amount (size) used of the extended buffer

//-----------------------------------------------------------------------------
// AS_AudioFile_ConvertToFile
//
// DESCRIPTION:
// Convert an audio file represented by the opened AS_AudioFile::Handle to a
// specific AS_Audio::FileType using the specified encoder settings. If the
// source file supports and contains tags, a null (zero) 'tags' parameter will
// tell the method to try and preserve them. A non-null parameter will set them
// using the provided information.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_FileOpenFailed   - if 'destPath' is invalid or could not be created
//  AS_StorageError_InvalidHandle    - if 'handle' is invalid
//  AS_StorageError_InvalidParameter - if one or more of the parameters are incorrect
//
AS_StorageError AS_API AS_AudioFile_ConvertToFile(
	const AS_AudioFile::Handle& handle,            // IN: file handle to convert from
	const AS_String& destPath,                     // IN: full path of file to create
	const AS_Audio::Track_EncoderSettings& encode, // IN: encoder settings to convert to
	const AS_Audio::Track_Tags* tags,              // IN: tags to set - null (zero) will preserve source tags if possible
	AS_Volume::InfoCallback callback,              // IN: progress callback function
	void* userData,                               // IN: client callback parameter
	UInt32 reserved = 0);                          // IN: reserved

//-----------------------------------------------------------------------------
// AS_AudioFile_Close
//
// DESCRIPTION:
// Close an AS_AudioFile::Handle opened by AS_Open_AudioFile.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_NotInitialized   - if the audio API could not be initialized
//  AS_StorageError_InvalidParameter - if the handle is invalid
//
AS_StorageError AS_API AS_AudioFile_Close(
	AS_AudioFile::Handle& handle); // IN: handle of file to close

#ifdef __cplusplus
}
#endif
#endif  // _AS_AudioFileH
