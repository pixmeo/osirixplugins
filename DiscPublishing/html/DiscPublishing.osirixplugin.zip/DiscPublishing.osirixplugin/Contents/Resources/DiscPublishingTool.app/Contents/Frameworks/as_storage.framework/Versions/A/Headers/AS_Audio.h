//-----------------------------------------------------------------------------
// AS_Audio.h
// Copyright (c) Sonic Solutions.  All rights reserved.
//-----------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////
//
// Notes: This API requires AS_StorageDevice_OpenFormat to be called first to
//        get a format handle and that AS_Format_Close be called when finished.
//
//        Track numbers (as also indicated in the comments) are one-based
//        (i.e. 1 = first track).
//
///////////////////////////////////////////////////////////////////////////////

#ifndef _AS_AudioH
#define _AS_AudioH

#include "AS_Format.h"
#include "AS_StorageTypes.h"


struct AS_Audio
{
	// Audio effects that may be applied to Audio CD creation.
	enum EffectType
	{
		Effect_FadeIn    = 0,  // Not available at this time
		Effect_FadeOut   = 1,  // Not available at this time
		Effect_Normalize = 2   // IN: (UInt32) 0 - Off, 1 - On; (UInt32) Flags, must be zero.
	};

	// Supported audio file types (used also for streaming). The name of each
	// type also describes its expected file extension. Please note that
	// customers without full audio support may only use File_PCM.
	enum FileType
	{
		File_AutoDetect = 0,  // Auto-detect the file type based on the file extension. Not available for streamed data.
		File_PCM        = 1,  // Raw PCM audio (CD-DA) decoding only.
		File_WAV        = 2,  // WAVE decoding and encoding.
		File_MP3        = 3,  // MP3 decoding and encoding (when enabled).
		File_WMA        = 4,  // WMA decoding and encoding.
		File_M4A        = 5,  // M4A decoding only. M4P is not supported. Requires QuickTime.
		File_OGG        = 6,  // OGG Vorbis decoding and encoding (when enabled).
		File_AAC        = 7,  // Raw AAC decoding only. Requires QuickTime.
		File_AIFF       = 8   // AIFF decoding only (.AIFF;.AIF;.AIFC). Requires QuickTime.
	};

	// Audio-specific properties that may be set for creation by use of the
	// AS_Format_SetAudioTrackProperty method.
	//
	// CD-Text strings are of type wchar_t unless otherwise specified. The
	// 'extPropIndex' parameter must be set to the CD-Text language type
	// (AS_StorageDevice::CDTextLanguageType).
	//
	// Track_PregapSize is the total Pregap size in sectors. It defaults to zero
	// except for the first track whose Pregap must be at least 150 sectors.
	//
	// Track_AudioStart may be used to start audio data in the Pregap. The value
	// represents the offset relative to the track start and must fall within
	// the range [-Track_PregapSize, 0]. Please note that the first track may
	// not start audio data within the first 150 sectors of its Pregap.
	enum Track_Property
	{
		Track_PregapSize = 0,  // IN: (UInt32) Pregap size in sectors
		Track_Indices    = 1,  // Not available at this time
		Track_ISRC       = 2,  // IN/OUT: 12 byte ISRC (L to R: 0-1 Country, 2-4 Registrant, 5-6 Year, 7-11 Designation)
		Track_Title      = 3,  // IN/OUT: String CD-Text Title
		Track_Performer  = 4,  // IN/OUT: String CD-Text Performer
		Track_Songwriter = 5,  // IN/OUT: String CD-Text Songwriter
		Track_Composer   = 6,  // IN/OUT: String CD-Text Composer
		Track_Arranger   = 7,  // IN/OUT: String CD-Text Arranger
		Track_Message    = 8,  // IN/OUT: String CD-Text Message
		Track_Genre      = 9,  // IN/OUT: String CD-Text Genre
		Track_GenreCode  = 10, // IN/OUT: String CD-Text Genre Code
		Track_AudioStart = 11  // IN: (SInt32) Start position of audio data relative to the track start
	};

	// Tag information that may be included when extracting CD-Audio to a file
	// format that supports such data (MP3, etc.).
	struct Track_Tags
	{
		UInt32 structSizeBytes;  // Size of structure in bytes
		UInt32 reserved;         // Reserved, must be zero
		AS_String * Track;
		AS_String * Title;
		AS_String * Artist;
		AS_String * Album;
		AS_String * Year;
		AS_String * Genre;
		AS_String * Comment;
		AS_String * Type;        // Not available at this time
	};

	// Bit fields used to denote which Track_Tags are supported for a given
	// file format. See AS_Format_GetSupportedTags.
	typedef UInt64 Track_TagID;
	static const Track_TagID Track_Tag_None    = 0;
	static const Track_TagID Track_Tag_Track   = (1 << 0);
	static const Track_TagID Track_Tag_Title   = (1 << 1);
	static const Track_TagID Track_Tag_Artist  = (1 << 2);
	static const Track_TagID Track_Tag_Album   = (1 << 3);
	static const Track_TagID Track_Tag_Year    = (1 << 4);
	static const Track_TagID Track_Tag_Genre   = (1 << 5);
	static const Track_TagID Track_Tag_Comment = (1 << 6);

	// Encoder settings for FileType encoders when extracting CD-Audio to file.
	// See also Track_EncoderSettings and AS_Format_ExtractAudioTrackToFile.
	struct EncoderSettings
	{
		// Bit rate flags
		enum BitRateType
		{
			CBR = 0x00000,  // Constant Bit Rate
			VBR = 0x00001,  // Variable Bit Rate
			ABR = 0x00002   // Average Bit Rate
		};

		// Stereo channel compression type
		enum ChannelType
		{
			NormalStereo = 0x0000,  // Normal stereo (no compression)
			JointStereo  = 0x0001   // Joint stereo compression
		};

		// Encoder algorithm quality. Higher quality generally means longer
		// encode times. Not all encoders support (all) quality levels and will
		// either ignore the value or choose the nearest value of equal or higher
		// quality. This value only affects the encoder algorithm and is not
		// directly related to the bit rate or sample frequency.
		enum Quality
		{
			Quality_Fixed   = -100,  // Encoding quality is fixed
			Quality_Default = 0,     // Default quality setting
			Quality_Lowest  = 100,   // Lowest (Fastest)
			Quality_200     = 200,
			Quality_300     = 300,
			Quality_400     = 400,
			Quality_500     = 500,
			Quality_600     = 600,
			Quality_700     = 700,
			Quality_800     = 800,
			Quality_900     = 900,
			Quality_Highest = 1000   // Highest (Slowest)
		};

		UInt32 structSizeBytes;   // Size of structure in bytes

		// Compression Settings
		BitRateType bitRateType;  // Bit rate flags
		ChannelType channelType;  // Stereo channel flags
		Quality quality;          // Algorithm quality
		UInt32 bytesPerSecond;    // # of bytes per second
		UInt32 reserved1;         // Reserved for future use
		UInt32 reserved2;         // Reserved for future use

		// Audio Settings
		UInt32 channels;          // # of channels
		UInt32 samplesPerSecond;  // # of samples per second
		UInt32 bitsPerSample;     // # of bits per sample per channel
	};

	// Audio encoder information used for extraction to file
	struct Track_EncoderSettings
	{
		UInt32 structSizeBytes;    // Size of structure in bytes
		FileType type;             // File type to encode to
		EncoderSettings settings;  // Encoder settings
	};

	// DRM status values used in AS_Format_CheckAudioPlaylist
	enum DRMStatus
	{
		DRM_OK        = 0,  // DRM status OK
		DRM_NoLicense = 1,  // No license
		DRM_BurnCount = 2,  // Burn count exceeded
		DRM_PlayCount = 3,  // Play count exceeded
		DRM_Playlist  = 4,  // Playlist restriction
		DRM_Generic   = 5   // Generic DRM error
	};

	// Callback method used by AS_Format_SetWMAReaderCallback to set up the
	// Microsoft Windows Media Audio (WMA) Digital Rights Management (DRM)
	// library. See the Windows Media Format SDK for further details.
	//
	// Example callback implementation:
	//
	// SInt32 SetupWMAReaderCallback(void *reserved, UInt32 rights, void **iwmReader)
	// {
	//    return WMCreateReader((IUnknown*)reserved, rights, (IWMReader**)iwmReader);
	// }
	typedef SInt32(AS_CALLBACK *CreateWMAReaderCallback)(
		void* reserved,     // Reserved IUnknown pointer (must be zero)
		UInt32 wmtRights,   // WMT_RIGHTS flags
		void** iwmReader);  // Double-Pointer to IWMReader object
};


#ifdef __cplusplus
extern "C"
{
#endif

//-----------------------------------------------------------------------------
// Audio API Functions
//-----------------------------------------------------------------------------

// Typical sequence for creating an audio CD:
//
//  1. AS_StorageDevice_OpenFormat
//  2. AS_Format_Create (see AS_Volume::Type_AudioCD)
//  3. AS_Format_CreateAudioPlaylist (if using DRM)
//  4. AS_Format_AddAudioTrackFromFile or AS_Format_AddAudioTrackFromStream2
//  5. AS_Format_AddAudioTrackEffect (optional)
//  6. AS_Format_SetAudioTrackProperty (optional)
//  7. AS_Format_CheckAudioPlaylist (if using DRM)
//  8. AS_Volume_Flush (flush to disc or GI - based on target specified)
//  9. AS_Format_CloseAudioPlaylist (if using DRM)
// 10. AS_Format_Close
//
// Note: CD-Text can be created via AS_Format_SetAudioTrackProperty by using
//       the CD-Text properties.


// Typical sequence to extract PCM tracks of an audio CD to file (WAV, MP3, etc):
//
// 1. AS_StorageDevice_OpenFormat
// 2. AS_Volume_Mount
// 3. AS_Format_AddAudioTrackEffect (optional)
// 4. for tracks 1..n AS_Format_ExtractAudioTrackToFile(tracks 1..n)
// 5. AS_Format_Close


//-----------------------------------------------------------------------------
// AS_Format_AddAudioTrackFromHD
//
// DEPRECATED:
// Please use AddAudioTrackFromFile instead. Supports AS_Audio::File_PCM only.
//
// Use of this method requires the host application to maintain and augment its
// own track index list to match that kept internally by the API. For this
// reason it is suggested that AddAudioTrackFromFile be used instead.
//
// DESCRIPTION:
// Add an audio track to media from a raw PCM audio file on hard drive.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//  AS_StorageError_InvalidAccess    - if the AS_Format object is mounted read-only
//  AS_StorageError_InvalidFile      - if the file does not meet the minimum size for CD-DA
//                                     (150 sectors - two seconds) or could not be set to output as PCM
//  AS_StorageError_InvalidOperation - if the AS_Format object is not mounted
//                                   - if more than 99 tracks are added
//  AS_StorageError_InvalidParameter - if one or more of the parameters are invalid
//  AS_StorageError_ReadError        - if there was an error determining the output size
//
AS_StorageError AS_API AS_Format_AddAudioTrackFromHD(  // RETURNS: error number
	const AS_Format& format,             // IN: layout reference
	const AS_File::Path& fullPathOnHD);  // IN: path to hard disc file from which to copy track data - not copied to media until Volume is flushed.

//-----------------------------------------------------------------------------
// AS_Format_AddAudioTrackFromStream
//
// DEPRECATED:
// Please use AddAudioTrackFromStream2 instead. Supports AS_Audio::File_PCM only.
//
// Use of this method requires the host application to maintain and augment its
// own track index list to match that kept internally by the API. For this
// reason it is suggested that AddAudioTrackFromStream2 be used instead.
//
// DESCRIPTION:
// Add an audio track to media from a raw PCM audio stream.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//  AS_StorageError_InvalidAccess    - if the AS_Format object is mounted read-only
//  AS_StorageError_InvalidFile      - if the data does not meet the minimum size for CD-DA
//                                     (150 sectors - two seconds).
//  AS_StorageError_InvalidOperation - if the AS_Format object is not mounted
//                                   - if more than 99 tracks are added
//  AS_StorageError_InvalidParameter - if one or more of the parameters are invalid
//
AS_StorageError AS_API AS_Format_AddAudioTrackFromStream(  // RETURNS: error number
	const AS_Format& format,             // IN: layout reference
	const AS_File::Size& streamLength,   // IN: size of stream (and ultimately file on media)
	AS_Volume::StreamCallback callback,  // IN: stream callback function for track data
	void* callerUse);                    // IN: stream callback userdata

//-----------------------------------------------------------------------------
// AS_Format_AddAudioTrackFromFile
//
// DESCRIPTION:
// Add an audio track to media from a file. Returns the one-based track number
// representing the file in the 'track' parameter.
//
// RETURN:
//  AS_StorageError_None              - ok
//  AS_StorageError_NotInitialized    - if the AS_Audio library could not start for non-PCM sources
//  AS_StorageError_NotSupported      - if the FileType is not supported
//  AS_StorageError_DRM_InvalidAccess - if the file is DRM and a debugger is detected
//  AS_StorageError_DRM_NoLicense     - if the file is DRM and has an insufficient license
//                                    - if the file is DRM and no license is found
//  AS_StorageError_DRM_NoWMAReader   - if the DRM stub library is not present for WMA DRM
//  AS_StorageError_Fatal             - if an unknown or unrecognized error occurs
//  AS_StorageError_FileOpenFailed    - if the file could not be opened
//  AS_StorageError_InvalidAccess     - if the AS_Format object is mounted read-only
//  AS_StorageError_InvalidFile       - if the file does not meet the minimum size for CD-DA
//                                      (150 sectors - two seconds) or could not be set to output as PCM
//  AS_StorageError_InvalidOperation  - if the AS_Format object is not mounted
//                                    - if more than 99 tracks are added
//  AS_StorageError_InvalidParameter  - if one or more of the parameters are invalid
//  AS_StorageError_InvalidSequence   - if AS_Format_CheckAudioPlaylist has been called
//                                    - if the file is DRM and AS_Format_CreateAudioPlaylist has not been called
//  AS_StorageError_ReadError         - if there was an error determining the output size
//
AS_StorageError AS_API AS_Format_AddAudioTrackFromFile(  // RETURNS: error number
	const AS_Format& format,             // IN: layout reference
	const AS_File::Path& fullPath,       // IN: full path
	const AS_Audio::FileType& fileType,  // IN: source (file) format
	UInt32& track);                      // OUT: track index reported back, 1 = first track

//-----------------------------------------------------------------------------
// AS_Format_AddAudioTrackFromStream2
//
// DESCRIPTION:
// Add an audio track to media from a stream. Returns the one-based track number
// representing the file in the 'track' parameter.
//
// The AS_Audio::FileType must be specified for stream data. Currently only
// AS_Audio::File_PCM is supported.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//  AS_StorageError_InvalidAccess    - if the AS_Format object is mounted read-only
//  AS_StorageError_InvalidFile      - if the data does not meet the minimum size for CD-DA
//                                     (150 sectors - two seconds) or could not be set to output as PCM
//  AS_StorageError_InvalidOperation - if the AS_Format object is not mounted
//                                   - if more than 99 tracks are added
//  AS_StorageError_InvalidParameter - if one or more of the parameters are invalid
//
AS_StorageError AS_API AS_Format_AddAudioTrackFromStream2(  // RETURNS: error number
	const AS_Format& format,             // IN: layout reference
	const AS_File::Size& streamLength,   // IN: size of stream (and ultimately file on media)
	AS_Volume::StreamCallback callback,  // IN: stream callback function for track data
	void* callerUse,                     // IN: stream callback userdata
	const AS_Audio::FileType& dataType,  // IN: source (stream data) format
	UInt32& track);                      // OUT: track index reported back, 1 = first track

//-----------------------------------------------------------------------------
// AS_Format_SetAudioTrackProperty
//
// DESCRIPTION:
// Set an AS_Audio::Track_Property for the given track number. Please see the
// notes for Track_Property for more information.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_NotImplemented   - if the property is not yet implemented
//  AS_StorageError_DeviceError      - if the property could not be set
//  AS_StorageError_InvalidAccess    - if the AS_Format object is mounted read-only
//  AS_StorageError_InvalidOperation - if called out of sequence or invalid for the given context
//  AS_StorageError_InvalidParameter - if one or more of the parameters are invalid
//
AS_StorageError AS_API AS_Format_SetAudioTrackProperty(
	const AS_Format& format,               // IN: layout reference
	const AS_Audio::Track_Property& prop,  // IN: audio property to set
	UInt32 trackNumber,                    // IN: track number, 1 = first track
	UInt32 propSize,                       // IN: size of data in propData buffer
	void* propData,                        // IN: property data
	UInt32 extPropIndex = 0,               // IN: reserved - index of extended property to set
	UInt32 extPropSize = 0,                // IN: reserved - size of extPropData buffer
	void* extPropData = 0);                // IN: reserved - extended property data to set

//-----------------------------------------------------------------------------
// AS_Format_AddAudioTrackEffect
//
// DESCRIPTION:
// Add an AS_Audio::EffectType effect to the specified track number.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_BufferOverflow   - if the provided buffer is not large enough
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//                                   - if an out of memory condition occurs
//  AS_StorageError_InvalidOperation - if called out of sequence or invalid for the given context
//  AS_StorageError_InvalidParameter - if one or more of the parameters are invalid
//
AS_StorageError AS_API AS_Format_AddAudioTrackEffect(
	const AS_Format& format,           // IN: layout reference
	UInt32 trackNumber,                // IN: track number to add the effect to, 1 = first track
	const AS_Audio::EffectType& type,  // IN: type of effect, i.e. Normalize
	UInt32 parametersSize,             // IN: size of the 'parameters' buffer in bytes
	void* parameters);                 // IN: optional parameters for the specified effect type

//-----------------------------------------------------------------------------
// AS_Format_GetSupportedTags
//
// DESCRIPTION:
// Get the Track_TagID(s) that are supported for the given AS_Audio::FileType.
// Some tags may be read but not written and vice-versa.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'type' is invalid
//
AS_StorageError AS_API AS_Format_GetSupportedTags(
	const AS_Audio::FileType& type,     // IN: FileType to query
	AS_Audio::Track_TagID& readTags,    // OUT: Tags that may be read
	AS_Audio::Track_TagID& writeTags);  // OUT: Tags that may be written

//-----------------------------------------------------------------------------
// AS_Format_ExtractAudioTrackToFile
//
// DESCRIPTION:
// Extracts a track from an audio CD to a file with the given path. The Pregap
// of a track may be extracted by specifying a negative 'startOffset' in bytes.
//
// Please note that the first 150 sectors of the Pregap of the first track
// cannot be extracted.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_NotInitialized   - if the AS_Audio library could not start
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//                                   - if an out of memory condition occurs
//  AS_StorageError_FileExists       - if the destination file already exists
//  AS_StorageError_FileNotFound     - if the track or Pregap could not be found
//  AS_StorageError_InvalidOperation - if called out of sequence or invalid for the given context
//  AS_StorageError_InvalidParameter - if track number does not exist
//                                   - if the specified path is not valid
//                                   - if the flags are incorrect
//                                   - if the startOffset and/or length exceed the length of the track
//  AS_StorageError_ReadError        - if the source track could not be read from
//  AS_StorageError_WriteError       - if the destination file could not be written to
//
AS_StorageError AS_API AS_Format_ExtractAudioTrackToFile(
	const AS_Format& format,                        // IN: layout reference
	UInt32 trackNumber,                             // IN: track number, 1 = first track
	const AS_File::Path& fullPath,                  // IN: the full path of the file
	UInt32 flags,                                   // IN: reserved (must be zero) - extraction flags
	SInt32 startOffset,                             // IN: start address in bytes, < 0 to include Pregap
	SInt32 length,                                  // IN: length in bytes, -1 = startOffset to end of track
	const AS_Audio::Track_Tags& tags,               // IN: optional file tags, ignored for WAV output
	const AS_Audio::Track_EncoderSettings& encode,  // IN: encoding settings
	AS_Volume::InfoCallback callback,               // IN: progress callback function
	void* callerUse,                                // IN: client callback parameter
	UInt32* reserved = 0);                          // OUT: reserved, must be NULL

//-----------------------------------------------------------------------------
// AS_Format_GetEncoderPresetCount
//
// DESCRIPTION:
// Get the number of predefined AS_Audio::EncoderSettings for a given
// AS_Audio::FileType.
//
// RETURN:
//  AS_StorageError_None         - ok
//  AS_StorageError_NotSupported - if encoding is not supported for the FileType
//  AS_StorageError_Fatal        - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_Format_GetEncoderPresetCount(
	const AS_Audio::FileType& fileType,  // IN: AS_Audio::FileType to encode to
	UInt32& count);                      // OUT: Number of presets

//-----------------------------------------------------------------------------
// AS_Format_GetEncoderPreset
//
// DESCRIPTION:
// Get predefined AS_Audio::EncoderSettings for a given AS_Audio::FileType by
// index. The per-FileType index value is zero-based and its upper bound is
// obtained by calling AS_Format_GetEncoderPresetCount.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_NotSupported     - if encoding is not supported for the FileType
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//  AS_StorageError_InvalidParameter - if 'index' is out of bounds
//
AS_StorageError AS_API AS_Format_GetEncoderPreset(
	const AS_Audio::FileType& fileType,    // IN: AS_Audio::FileType to encode to
	UInt32 index,                          // IN: Zero-based index of FileType preset
	AS_Audio::EncoderSettings& settings);  // OUT: Encoder settings

//-----------------------------------------------------------------------------
// AS_Format_VerifyEncoderSettings
//
// DESCRIPTION:
// Verify that AS_Audio::EncoderSettings are valid for an AS_Audio::FileType.
// The 'updated' parameter is set to true if Quality_Default is used or if the
// 'settings' had to be changed to match what the encoder is capable of. In
// such a case if 'newSettings' is non-null it will be set to the updated
// values.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_NotSupported     - if encoding is not supported for the FileType
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//  AS_StorageError_InvalidParameter - if the settings could not be corrected
//
AS_StorageError AS_API AS_Format_VerifyEncoderSettings(
	const AS_Audio::FileType& fileType,           // IN: AS_Audio::FileType to encode to
	const AS_Audio::EncoderSettings& settings,    // IN: Settings to verify
	bool& updated,                                // OUT: Did the settings have to be changed to work with the encoder
	AS_Audio::EncoderSettings* newSettings = 0);  // OUT: (Optional) New settings if 'updated' is true

//-----------------------------------------------------------------------------
// AS_Format_SetWMAReaderCallback
//
// DESCRIPTION:
// Sets up the Microsoft Windows Media Audio (WMA) Digital Rights Management
// (DRM) library. See the notes above for AS_Audio::CreateWMAReaderCallback and
// the Windows Media Format SDK for further details. This method must only be
// called once and before any AS_Audio or AS_AudioFile methods are used. If
// this method is not called a default reader will be provided that only
// supports non-DRM WMA decoding.
//
// RETURN:
//  AS_StorageError_None           - ok
//  AS_StorageError_NotInitialized - if the AS_Audio library could not start
//
AS_StorageError AS_API AS_Format_SetWMAReaderCallback(
	UInt32 flags,                                 // IN: Reserved flags (must be zero)
	AS_Audio::CreateWMAReaderCallback callback);  // IN: AS_Audio::CreateWMAReaderCallback

//-----------------------------------------------------------------------------
// AS_Format_CreateAudioPlaylist
//
// DESCRIPTION:
// Creates a new audio playlist to support Windows Media DRM. The playlist is
// populated by making calls to AS_Format_AddAudioTrackFromFile. Adding tracks
// from streamed data is not supported.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_NotInitialized   - if the AS_Audio library could not start
//  AS_StorageError_InvalidOperation - if a playlist already exists
//  AS_StorageError_InvalidParameter - if the AS_Format object is invalid
//
AS_StorageError AS_API AS_Format_CreateAudioPlaylist(
	const AS_Format& format);  // IN: layout reference

//-----------------------------------------------------------------------------
// AS_Format_CheckAudioPlaylist
//
// DESCRIPTION:
// Checks the existing playlist created by AS_Format_CreateAudioPlaylist to
// determine the AS_Audio::DRMStatus of each track that has been added to it
// with AS_Format_AddAudioTrackFromFile. This method may be called only once
// per playlist and afterwards no more tracks may be added to it.
//
// Please note that this method must be called prior to calling
// AS_Volume_Prepare and/or AS_Volume_Flush. Otherwise those methods will
// return AS_StorageError_InvalidSequence.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_NotInitialized   - if the AS_Audio library could not start
//  AS_StorageError_DRM_NoLicense    - if the playlist cannot be burned
//  AS_StorageError_InvalidOperation - if there is no current playlist
//                                   - if this method is called more than once
//  AS_StorageError_InvalidParameter - if one or more parameters are invalid
//  AS_StorageError_InvalidSequence  - if the playlist is empty
//
AS_StorageError AS_API AS_Format_CheckAudioPlaylist(
	const AS_Format& format,  // IN: layout reference
	UInt32 bufferSizeBytes,   // IN: Size of result buffer in bytes
	UInt32* results);         // OUT: Array of results in playlist order

//-----------------------------------------------------------------------------
// AS_Format_CloseAudioPlaylist
//
// DESCRIPTION:
// Closes the existing audio playlist. Subsequent calls to
// AS_Format_AddAudioTrackFromFile will not make use of the Windows Media DRM
// mechanism. This method must be called before AS_Format_CreateAudioPlaylist
// may be used again.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_NotInitialized   - if the AS_Audio library could not start
//  AS_StorageError_InvalidOperation - if there is no current playlist
//  AS_StorageError_InvalidParameter - if the AS_Format object is invalid
//
AS_StorageError AS_API AS_Format_CloseAudioPlaylist(
	const AS_Format& format);  // IN: layout reference


//-----------------------------------------------------------------------------
// AS_StorageDevice_PlayAudio
//
// DESCRIPTION:
// Play the audio CD in the device  
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_DeviceNotReady	 - if there is no CD
//  AS_StorageError_InvalidParameter - if the device object is invalid
//
AS_StorageError AS_API AS_StorageDevice_PlayAudio(
	const AS_StorageDevice& device, // IN: Device with the CD-DA media to play
	UInt32 startLBA,                // IN: Sector to start playback from
	UInt32 numSectors);              // IN: Number of sectors to play

//-----------------------------------------------------------------------------
// AS_StorageDevice_PauseResumeAudio
//
// DESCRIPTION:
// Pause or resum the audio CD player
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_DeviceNotReady	 - if there is no CD
//  AS_StorageError_InvalidParameter - if the device object is invalid
//
AS_StorageError AS_API AS_StorageDevice_PauseResumeAudio(
	const AS_StorageDevice& device, // IN: Device playing the CD-DA media
	UInt32 resume);                  // IN: Zero to pause playback, Non-zero to resume

//-----------------------------------------------------------------------------
// AS_StorageDevice_StopAudio
//
// DESCRIPTION:
// Stop the audio CD player
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_DeviceNotReady	 - if there is no CD
//  AS_StorageError_InvalidParameter - if the device object is invalid
//
AS_StorageError AS_API AS_StorageDevice_StopAudio(
	const AS_StorageDevice& device); // IN: Device with the CD-DA media to stop playback of

//-----------------------------------------------------------------------------
// AS_StorageDevice_GetPositionAudio
//
// DESCRIPTION:
// Get the current position of playing
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_DeviceNotReady	 - if there is no CD
//  AS_StorageError_InvalidParameter - if the device object is invalid
//
AS_StorageError AS_API AS_StorageDevice_GetPositionAudio(
	const AS_StorageDevice& device, // IN: Device playing the CD-DA media
	SInt32* trackRelativePos,       // OUT: Track relative position in sectors
	UInt32* absolutePos);            // OUT: Absolute position in sectors

#ifdef __cplusplus
}
#endif
#endif //_AS_AudioH
