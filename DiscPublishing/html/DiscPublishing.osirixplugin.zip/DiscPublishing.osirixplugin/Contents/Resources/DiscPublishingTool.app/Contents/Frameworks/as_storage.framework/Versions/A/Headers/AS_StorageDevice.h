//-----------------------------------------------------------------------------
// AS_StorageDevice.h
// Copyright (c) Sonic Solutions.  All rights reserved.
//-----------------------------------------------------------------------------
#ifndef __AS_StorageDevice_h__
#define __AS_StorageDevice_h__

#include "AS_StorageTypes.h"
#include "AS_StorageError.h"

#ifdef __cplusplus
extern "C"
{
#endif

struct AS_StorageDevice
{
	typedef UInt32 Handle;

	typedef UInt32 Type;
	static const Type Type_Device = 0;
	static const Type Type_File   = (1 << 0);
	static const Type Type_Folder = (1 << 2);

	Handle    myHandle;             // OUT: Device handle
	UInt32    reserved;             // Reserved for future use
	AS_String devicePath;           // OUT: Path to file device
	AS_String deviceXMLOptionsPath; //  IN: DEPRECATED: Optional XML file describing Qflix (or other) options.
	                                //      Please use SetDeviceProperty(DevProp_DeviceXMLOptionsPath) instead.
	Type      deviceType;           // OUT: DEPRECATED: Returns the AS_StorageDevice::Type that is set internally.
	                                //      Please use GetDeviceProperty(DevProp_DeviceKind) instead.

	static const Handle LastUsedDevice = 0;

	// Tray control commands
	enum TrayControls
	{
		// INTERNAL NOTE: Defines from EpxTrayControl
		Tray_Control_Lock       = 0, // Prevent tray from moving
		Tray_Control_Unlock     = 1, // Allow tray to be ejected/inserted
		Tray_Control_Open       = 2, // Asynchronous version of open tray
		Tray_Control_Close      = 3, // Asynchronous version of close tray
		Tray_Control_Open_Sync  = 4, // Synchronous version of open tray
		Tray_Control_Close_Sync = 5  // Synchronous version of close tray
	};

	enum DeviceState
	{
		// INTERNAL NOTE: Defines from EpxCheckMedia
		State_Not_Ready      = 70, // Generally indicates no media in device
		State_Ready          = 17, // Device is ready
		State_Becoming_Ready = 71  // Device is busy
	};

	enum Erase_Type
	{
		// INTERNAL NOTE: Defines from EpxErase
		Quick_Erase      = 0,
		Long_Erase       = 1,
		Quick_Destroy_RO = 2,
		Long_Destroy_RO  = 3
	};

	typedef wchar_t* UnicodeString;

	typedef UInt32 TrayStatus_Type;
	static const TrayStatus_Type TrayStatus_Unknown = 1; // Tray status is unknown
	static const TrayStatus_Type TrayStatus_Open    = 2; // Tray is open
	static const TrayStatus_Type TrayStatus_Closed  = 3; // Tray is closed

	// Device scan type passed in to AS_GetStorageDeviceCount
	typedef UInt32 Scan_Flags;
	static const Scan_Flags Scan_All     = 0;
	static const Scan_Flags Scan_Optical = (1 << 0);
	static const Scan_Flags Scan_Tape    = (1 << 1);

	// Bus Kind / Bus Info query properties
	typedef UInt32 Bus_Kind;
	typedef struct
	{
		Bus_Kind bus_kind;
		UInt8    addr_valid;
		UInt8    addr_adapter_id;
		UInt8    addr_target_id;
		UInt8    addr_lun_id;
		UInt8    Reserved[128];
	} Bus_Info;

	// INTERNAL NOTE: Defines from EPX_DEV_PROP_BUSTYPE
	static const Bus_Kind Bus_ATAPI   = 25;
	static const Bus_Kind Bus_SCSI    = 26;
	static const Bus_Kind Bus_USB     = 28;
	static const Bus_Kind Bus_USB2    = 31;
	static const Bus_Kind Bus_1394    = 32;
	static const Bus_Kind Bus_Unknown = 0;

	// Authentication query properties
	typedef UInt32 Authentication_Type;
	// INTERNAL NOTE: Defines from EPX_DEV_PROP_*_AUTHENTICATION_TYPES
	static const Authentication_Type Authentication_None = 0;
	static const Authentication_Type Authentication_CPPM = (1 << 0); // CSS or CPPM authentication supported
	static const Authentication_Type Authentication_CPRM = (1 << 1); // CPRM authentication supported
	static const Authentication_Type Authentication_AACS = (1 << 2); // AACS authentication supported

	// DVD-V device region state
	typedef UInt32 RegionState_Type;
	static const RegionState_Type RegionState_NotSet        = 0; // No region is set
	static const RegionState_Type RegionState_Set           = 1; // Region has been set
	static const RegionState_Type RegionState_LastChanceSet = 2; // Drive region is set, with additional restrictions required to make the change
	static const RegionState_Type RegionState_Permanent     = 3; // Drive region has been set permanently, but may be reset by the vendor if necessary

	// DVD-V device region information
	typedef struct
	{
		RegionState_Type CurrentState;
		UInt32           CurrentCode;              // Bit-mask of which of the eight regions are supported (0 = all regions). For device only one will be set
		UInt32           NumVendorResetsAvailable; // Number of vendor resets available
		UInt32           NumUserChangesAvailable;  // Number of user region changes available
		UInt32           Reserved[4];              // Reserved for future region copyright schema
	} RegionInfo_Type;

	// Device type
	typedef UInt32 DevType;
	// INTERNAL NOTE: Defines from EpxDevType
	static const DevType IsFile    = (1 << 0);
	static const DevType IsOptical = (1 << 1);
	static const DevType IsTape    = (1 << 2);

	// Device feature
	typedef UInt32 DevFeature;
	// INTERNAL NOTE: Defines from EpxDevFeaturesType
	static const DevFeature DevFeature_Writer       = (1 << 0); // Supports writing
	static const DevFeature DevFeature_MediaQuality = (1 << 5); // Supports reporting media quality
	static const DevFeature DevFeature_DAP          = (1 << 6); // Supports Digital Audio Playback (DAP)
	static const DevFeature DevFeature_DestroyRO    = (1 << 7); // Supports destroying RO media

	// Device properties
	enum DevProp_Type                        // Type                   Description
	{
		// INTERNAL NOTE: Most defines from EpxGetDeviceProperty
		DevProp_Description       = 0,       // UnicodeString          OUT: Device description
		DevProp_MakeName          = 1,       // UnicodeString          OUT: Device make
		DevProp_ModelName         = 2,       // UnicodeString          OUT: Device model
		DevProp_Version           = 3,       // UnicodeString          OUT: Device version
		DevProp_DrivePath         = 6,       // UnicodeString          OUT: Device drive letter or path of file device
		DevProp_DevType           = 7,       // DevType                OUT: DevType: (File, Optical, Tape)
		DevProp_Features          = 10,      // DevFeature             OUT: Bit-mask of supported device features
		DevProp_MedTypesCapable   = 11,      // MediaKind              OUT: Bit-mask of supported media types (DVD-RW, DVD+RW, CD-RW, CD-R, etc.)
		DevProp_TrayStatus        = 12,      // TrayStatus_Type        OUT: Current tray status
		DevProp_Bus_Info          = 17,      // Bus_Info               OUT: Bus kind and adapter/target/lun information
		DevProp_NumWriteLayers	  = 20,		 // UInt32                 OUT: Number of layers the device is capable of writing (per media type). Requires DevProp_MedTypesCapable media types.
		DevProp_AuthenTypes       = 0x30004, // Authentication_Type    OUT: Authentication type
		DevProp_SerialNum         = 0x30005, // UInt8[]                OUT: Serial number (255 bytes max including null terminator)
		DevProp_CopyProtection    = 0x30006, // ProtectionType         OUT: Bit-mask of Copy protection types supported
		DevProp_MaxTransferSize   = 18,      // UInt32                 OUT: Maximum transfer size of device in bytes
		DevProp_BufferSize        = 21,      // UInt32                 OUT: Device buffer size in bytes
		DevProp_RegionInfo        = 22,      // RegionInfo_Type        OUT: Device copy protection region information
		DevProp_NumEjectPresses   = 23,      // UInt32                 OUT: Number of times the eject button was hit
		DevProp_DeviceKind        = 99,      // Type                   IN/OUT: Type: (Type_File, Type_Folder, Type_Device)
		DevProp_MaxCopyReadErrors = 100,     // UInt32                 IN/OUT: Max read errors allowed on next physical copy from this source to any target(s) (0 = fail on first read error, 0xffffffff = never fail on read errors, N = fail after N read errors)
		DevProp_DeviceXMLOptions  = 101,     // AS_String              IN/OUT: AS_String for full path to optional XML job file
	};

	// Supported media types
	typedef UInt64 MediaKind;
	// INTERNAL NOTE: Defines from EpxMedType
	static const MediaKind MediaIsCdRom       = (1 << 0);
	static const MediaKind MediaIsCdr         = (1 << 1);
	static const MediaKind MediaIsCdrw        = (1 << 2);
	static const MediaKind MediaIsDdCdrom     = (1 << 3);
	static const MediaKind MediaIsDdCdr       = (1 << 4);
	static const MediaKind MediaIsDdCdrw      = (1 << 5);
	static const MediaKind MediaIsDvdRom      = (1 << 6);
	static const MediaKind MediaIsDvdr        = (1 << 7);
	static const MediaKind MediaIsDvdrw       = (1 << 8);
	static const MediaKind MediaIsDvdpr       = (1 << 9);
	static const MediaKind MediaIsDvdprw      = (1 << 10);
	static const MediaKind MediaIsDvdRam      = (1 << 11);
	static const MediaKind MediaIsDvdpr9      = (1 << 12);
	static const MediaKind MediaIsDvdr9       = (1 << 13);
	static const MediaKind MediaIsBdr         = (1 << 14);
	static const MediaKind MediaIsBdre        = (1 << 15);
	static const MediaKind MediaIsHdDvdRom    = (1 << 16);
	static const MediaKind MediaIsHdDvdr      = (1 << 17);
	static const MediaKind MediaIsHdDvdrw     = (1 << 18);
	static const MediaKind MediaIsBdrom       = (1 << 19);
	static const MediaKind MediaIsSeqTape     = ((UInt64)1 << 31);
	static const MediaKind MediaIsQFlix       = ((UInt64)1 << 32);
	static const MediaKind MediaIsQFlixPro    = ((UInt64)1 << 33);
	static const MediaKind MediaIsDVDDownload = ((UInt64)1 << 34);

	// MediaState is valid only if the device reports State_Ready
	// Incompatible media is represented by the following states: Readable = false, Writable = false
	typedef UInt32 MediaState;
	// INTERNAL NOTE: Defines from EpxMedIoStateType
	static const MediaState MediaIsReadable   = (1 << 0);  // Readable
	static const MediaState MediaIsWritable   = (1 << 1);  // Writable
	static const MediaState MediaIsInvisible  = (1 << 2);  // Invisible
	static const MediaState MediaIsAppendable = (1 << 3);  // Appendable
	static const MediaState MediaIsRewritable = (1 << 5);  // Rewritable
	static const MediaState MediaIsErasable   = (1 << 7);  // Erasable
	static const MediaState MediaIsProtected  = (1 << 10); // Protected
	static const MediaState MediaIsBlank      = (1 << 12); // Blank
	static const MediaState LayerJumpSettable = (1 << 13); // Layer jump address may be set

	typedef UInt32 MediaFeatures;
	// INTERNAL NOTE: Defines from EpxMedFeaturesType
	static const MediaFeatures MediaCanBeDestroyed = (1 << 9); // Destroyable

	typedef UInt32 SpeedSetting_Type;
	// INTERNAL NOTE: Defines from EPX_SPEED_*
	static const SpeedSetting_Type Speed_Min = 0;          // Minimum speed
	static const SpeedSetting_Type Speed_Max = 0xffffffff; // Maximum speed
	static const SpeedSetting_Type Speed_Var = 0xfffffffe; // Variable speed

	// Returned during query of DevProp_CopyProtection and MedProp_CopyProtection
	typedef UInt32 ProtectionType;
	static const ProtectionType ProtectionType_None               = 0;         // Drive/media offers no copy protection
	static const ProtectionType ProtectionType_Qflix_CSS          = (1 << 0);  // Drive/media offers Qflix Pro v2.0 CSS protection
	static const ProtectionType ProtectionType_Qflix_Consumer_CSS = (1 << 3);  // Drive/media offers Qflix Consumer CSS copy protection
	static const ProtectionType ProtectionType_DU1_2054           = (1 << 4);  // Drive/media accepts 2054
	static const ProtectionType ProtectionType_DU1_2064           = (1 << 5);  // Drive/media accepts 2064
	static const ProtectionType ProtectionType_DU1_2048           = (1 << 6);  // Drive/media works with 2048 only and generates the rest
	static const ProtectionType ProtectionType_DVDDownload_CSS    = (1 << 9);  // Drive/media offers DVD Forum's CSS copy protection
	static const ProtectionType ProtectionType_GuardBlock_BadECC  = (1 << 16); // DEPRECATED: Drive/media offers GuardBlock "Bad ECC blocks"
	static const ProtectionType ProtectionType_CPRM               = (1 << 17); // Drive/media can write CPRM protection
	static const ProtectionType ProtectionType_AACS               = (1 << 18); // Drive/media can write AACS protection

	typedef UInt32 FileFormatType;
	// INTERNAL NOTE: Defines from EPX_MEDIA_PROP_FILE_FORMAT
	static const FileFormatType FormatType_Unknown           = 0;
	static const FileFormatType FormatType_Raw               = 1;
	static const FileFormatType FormatType_OpticalDetect     = 2;
	static const FileFormatType FormatType_Raw_2048          = 3;
	static const FileFormatType FormatType_Raw_2336          = 4;
	static const FileFormatType FormatType_Raw_2352          = 5;
	static const FileFormatType FormatType_GI                = 6;
	static const FileFormatType FormatType_ISO_SecureData    = 7; // Certain data is protected but filesystem is clear (not supported by most SDKs)
	static const FileFormatType FormatType_ISO_SecureArchive = 8; // Entire file is protected (not supported by most SDKs)

	// CD-Text languages to be used as the 'property_index' parameter of
	// AS_StorageDevice_SetMediaProperty and AS_StorageDevice_SetTrackProperty
	typedef UInt32 CDTextLanguageType;
	// INTERNAL NOTE: Defines from EPX_MEDIA_PROP_CDTEXT_LANGUAGES
	static const CDTextLanguageType CDTEXT_LANG_GERMAN   = 0x08;
	static const CDTextLanguageType CDTEXT_LANG_ENGLISH  = 0x09;
	static const CDTextLanguageType CDTEXT_LANG_SPANISH  = 0x0a;
	static const CDTextLanguageType CDTEXT_LANG_FRENCH   = 0x0f;
	static const CDTextLanguageType CDTEXT_LANG_ITALIAN  = 0x15;
	static const CDTextLanguageType CDTEXT_LANG_DUTCH    = 0x1d;
	static const CDTextLanguageType CDTEXT_LANG_RUSSIAN  = 0x56;
	static const CDTextLanguageType CDTEXT_LANG_KOREAN   = 0x65;
	static const CDTextLanguageType CDTEXT_LANG_JAPANESE = 0x69;
	static const CDTextLanguageType CDTEXT_LANG_CHINESE  = 0x75;

	typedef UInt32 MediaPropBookType;
	// INTERNAL NOTE: Defines from EPX_MEDIA_PROP_BOOK_TYPE
	static const MediaPropBookType MediaPropBookType_INVALID = 0xff;
	static const MediaPropBookType MediaPropBookType_DVDROM  = 0x00;
	static const MediaPropBookType MediaPropBookType_DVDRAM  = 0x01;
	static const MediaPropBookType MediaPropBookType_DVDR    = 0x02;
	static const MediaPropBookType MediaPropBookType_DVDRW   = 0x03;
	static const MediaPropBookType MediaPropBookType_DVDPRW  = 0x09;
	static const MediaPropBookType MediaPropBookType_DVDPR   = 0x0A;
	static const MediaPropBookType MediaPropBookType_DVDPR9  = 0x0E;

	typedef UInt32 LayerPropType;
	// INTERNAL NOTE: Defines from EpxLayerPropType
	static const LayerPropType LayerProp_Symmetrical = 1;
	static const LayerPropType LayerProp_Contiguous  = 2;

	typedef UInt32 LayerType;
	// INTERNAL NOTE: Defines from EPX_MEDIA_PROP_LAYER_TYPE
	static const LayerType Layer_None = 0;
	static const LayerType Layer_OTP  = 1;
	static const LayerType Layer_PTP  = 2;

	typedef UInt32 MediaQualityType;
	// INTERNAL NOTE: Defines from EPX_MEDIA_PROP_QUALITY
	static const MediaQualityType MediaQuality_Unsupported = 0;
	static const MediaQualityType MediaQuality_Unknown     = 1;
	static const MediaQualityType MediaQuality_Good        = 2;
	static const MediaQualityType MediaQuality_Normal      = 3;
	static const MediaQualityType MediaQuality_Poor        = 4;
	static const MediaQualityType MediaQuality_Error       = 5;

	typedef UInt32 MediaFormatType;
	// INTERNAL NOTES: Defines from EPX_MEDIA_PROP_FORMAT_TYPES
	static const MediaFormatType	MediaFormat_None				= 0;
	static const MediaFormatType	MediaFormat_Standard			= 1;
	static const MediaFormatType	MediaFormat_HighDensity			= 2;
	static const MediaFormatType	MediaFormat_DefectManagement	= 3;

	// MediaProp_Type is valid only if the device reports State_Ready
	enum MediaProp_Type                                  // Type                   Description
	{
		// INTERNAL NOTE: Most defines from EpxGetMediaProperty
		MedProp_Num_Sessions               = 3,          // UInt32                 OUT: Number of sessions
		MedProp_Num_Tracks                 = 4,          // UInt32                 OUT: Number of tracks
		MedProp_Num_Layers                 = 5,          // UInt32                 IN/OUT: Number of layers: 2 = dual layer, 1 = single layer
		MedProp_LayerType                  = 6,          // LayerType              OUT: Type of layer (None, OTP, PTP)
		MedProp_LayerProperties            = 7,          // LayerPropType          OUT: Layer property type (Symmetrical, Contiguous)
		MedProp_MaxLayerJumpAddr           = 8,          // UInt32                 IN/OUT: Location of max layer jump address (UInt32[] returns all layers, otherwise returns layer 0)
		MedProp_LayerStart                 = 9,          // UInt32                 IN/OUT: Location of layer start (UInt32[] returns start of all layers, otherwise returns start of layer 0)
		MedProp_State                      = 12,         // MediaState             OUT: State of media (Writable, Protected, etc.)
		MedProp_Features                   = 13,         // MediaFeatures          OUT: Features of media (Destroy, etc.)
		MedProp_Bytes_Used                 = 18,         // UInt64                 OUT: Media space used in bytes
		MedProp_Bytes_Free                 = 19,         // UInt64                 OUT: Media space free in bytes
		MedProp_Kind                       = 30,         // MediaKind              IN/OUT: (IN/OUT for GI files, otherwise OUT only) DVD-RW, DVD+RW, CD-RW, CD-R, etc.
		MedProp_FileFormat                 = 31,         // FileFormatType         IN/OUT: Format type of file device
		MedProp_Manufacturer               = 22,         // UnicodeString          OUT: Media Vendor ID from disc
		MedProp_CurRead_DataRates          = 23,         // UInt32                 IN/OUT: Current read speed in kbyte/s
		MedProp_CurWrite_DataRates         = 24,         // UInt32                 IN: Current write speed in kbyte/s
		MedProp_WriteList_DataRates        = 26,         // UInt32[]               OUT: Array of supported write data rates in kbyte/s
		MedProp_LayerJumpAddr              = 37,         // UInt64                 IN/OUT: Location of layer jump address
		MedProp_MediaQuality               = 39,         // MediaQualityType       OUT: Quality of media
		MedProp_FormatCapacity			   = 42,		 // UInt32				   OUT: Format capacity of media in blocks
		MedProp_MinLayerJumpAddr           = 45,         // UInt64                 OUT: Location of the minimum layer jump address
		MedProp_SparingAreaSize            = 46,         // UInt32                 IN/OUT: Spare area allocated
		MedProp_Book_Type                  = 49,         // UInt32                 IN: Media book-type: Valid for DVD+R and DVD+RW only
		MedProp_SparingAreaUsed            = 50,         // UInt32                 IN/OUT: Spare area used
		MedProp_CurRead_Hundredth_X        = 0x00010000, // UInt32                 IN/OUT: Current read speed in 1/100ths X
		MedProp_CurWrite_Hundredth_X       = 0x00010001, // UInt32                 IN: Current write speed in 1/100ths X
		MedProp_WriteList_Hundredth_X      = 0x00010003, // UInt32[]               OUT: Array of supported write data rates in 1/100ths X
		MedProp_CDText_MediaCatalogNum     = 0x00020000, // UnicodeString          IN/OUT: CD-Text Media Catalog Number (MCN)
		MedProp_CDText_Title               = 0x00020001, // UnicodeString          IN/OUT: CD-Text media title
		MedProp_CDText_Performer           = 0x00020002, // UnicodeString          IN/OUT: CD-Text media performer
		MedProp_CDText_Songwriter          = 0x00020003, // UnicodeString          IN/OUT: CD-Text media songwriter
		MedProp_CDText_Composer            = 0x00020004, // UnicodeString          IN/OUT: CD-Text media composer
		MedProp_CDText_Arranger            = 0x00020005, // UnicodeString          IN/OUT: CD-Text media arranger
		MedProp_CDText_Message             = 0x00020006, // UnicodeString          IN/OUT: CD-Text media message
		MedProp_CDText_Genre               = 0x00020007, // UnicodeString          IN/OUT: CD-Text media genre
		MedProp_CDText_Genre_Code          = 0x00020008, // UnicodeString          IN/OUT: CD-Text media genre code
		MedProp_CDText_NumLanguages        = 0x00020009, // UInt32                 OUT: Number of languages with CDText on the media
		MedProp_CDText_Languages           = 0x0002000a, // UInt32[]               OUT: Array of languages with CDText (see CDTextLanguageType)
		MedProp_CurAuthenType              = 0x00030004, // Authentication_Type    OUT: Authentication type of the media
		MedProp_ExcludedDVDPlaybackRegions = 0x00030005, // UInt32                 IN/OUT: Bit-mask of the regions excluded from playback in leadin (IN only supported when writing leadin)
		MedProp_CopyProtection             = 0x00030006, // ProtectionType         OUT: Bit-mask of ProtectionType(s) supported by the media
		MedProp_TestWrite                  = 99,         // UInt32                 IN/OUT: TestWrite: 1 = enabled, 0 = disabled. Reports invalid media if not supported
		MedProp_RecordMode                 = 100,        // RecordMode             IN/OUT: To get/set the recording mode
		MedProp_DataMode                   = 101,        // DataMode               IN/OUT: To get/set the data mode
	};

	// Track properties
	typedef UInt32 TrackProp_TrackType;
	// INTERNAL NOTE: Defines from EPX_TRACK_PROP_TYPE
	static const TrackProp_TrackType TrackType_Audio     = 0;
	static const TrackProp_TrackType TrackType_Data      = 1;
	static const TrackProp_TrackType TrackType_DataMode2 = 2;
	static const TrackProp_TrackType TrackType_Blank     = 69;

	typedef UInt32 TrackProp_RecordMode_Type;
	// INTERNAL NOTE: Defines from EPX_TRACK_PROP_RECORD_MODE
	static const TrackProp_RecordMode_Type TrackMode_None                   = 0;
	static const TrackProp_RecordMode_Type TrackMode_TAO                    = 1;
	static const TrackProp_RecordMode_Type TrackMode_SAO                    = 2;
	static const TrackProp_RecordMode_Type TrackMode_FixedPacket            = 3;
	static const TrackProp_RecordMode_Type TrackMode_VarPacket              = 4;
	static const TrackProp_RecordMode_Type TrackMode_Incremental            = 5;
	static const TrackProp_RecordMode_Type TrackMode_RestrictOvr            = 6;
	static const TrackProp_RecordMode_Type TrackMode_Standard               = 7;
	static const TrackProp_RecordMode_Type TrackMode_SAO_Finalize           = 8;
	static const TrackProp_RecordMode_Type TrackMode_LayerJump              = 9;
	static const TrackProp_RecordMode_Type TrackMode_POW                    = 10;
	static const TrackProp_RecordMode_Type TrackMode_Incremental_Borderless = 11;

	typedef TrackProp_TrackType DataMode;
	static const DataMode DataMode_Audio     = TrackType_Audio;
	static const DataMode DataMode_Data      = TrackType_Data;
	static const DataMode DataMode_DataMode2 = TrackType_DataMode2;
	static const DataMode DataMode_Blank     = TrackType_Blank;

	typedef UInt32 RecordMode;
	static const RecordMode RecordMode_None                   = TrackMode_None;
	static const RecordMode RecordMode_TAO                    = TrackMode_TAO;
	static const RecordMode RecordMode_SAO                    = TrackMode_SAO;
	static const RecordMode RecordMode_FixedPacket            = TrackMode_FixedPacket;
	static const RecordMode RecordMode_VarPacket              = TrackMode_VarPacket;
	static const RecordMode RecordMode_Incremental            = TrackMode_Incremental;
	static const RecordMode RecordMode_RestrictOvr            = TrackMode_RestrictOvr;
	static const RecordMode RecordMode_Standard               = TrackMode_Standard;
	static const RecordMode RecordMode_SAO_Finalize           = TrackMode_SAO_Finalize;
	static const RecordMode RecordMode_LayerJump              = TrackMode_LayerJump;
	static const RecordMode RecordMode_POW                    = TrackMode_POW;
	static const RecordMode RecordMode_Incremental_Borderless = TrackMode_Incremental_Borderless;

	typedef UInt32 TrackProp_IOState;
	// INTERNAL NOTE: Defines from EpxTrkIoStateType
	static const TrackProp_IOState Track_IOState_Writable    = 0x00000002;
	static const TrackProp_IOState Track_IOState_Invisible   = 0x00000004;
	static const TrackProp_IOState Track_IOState_Appendable  = 0x00000008;
	static const TrackProp_IOState Track_IOState_Open        = 0x00000010; // Equivalent to appendable except for RO
	static const TrackProp_IOState Track_IOState_Rewritable  = 0x00000020;
	static const TrackProp_IOState Track_IOState_AutoJump    = 0x00000040; // Note: Different from media state
	static const TrackProp_IOState Track_IOState_Erasable    = 0x00000080;
	static const TrackProp_IOState Track_IOState_Formattable = 0x00000100;
	static const TrackProp_IOState Track_IOState_Expandable  = 0x00000800; // Note: Different from media state
	static const TrackProp_IOState Track_IOState_Blank       = 0x00001000;

	// TrackProp_Type is valid only if the device reports State_Ready
	enum TrackProp_Type                   // Type                         Description
	{
		// INTERNAL NOTE: Most defines from EpxGetTrackProperty
		TrackProp_BlockSize         = 1,  // UInt32                       IN/OUT: Block size in bytes (only Tape can select new block size)
		TrackProp_WriteFrameSize    = 2,  // UInt32                       IN/OUT: Write frame size in blocks
		TrackProp_OptimalFrameSize  = 3,  // UInt32                       IN/OUT: Optimal write frame size in blocks
		TrackProp_TrkType           = 4,  // TrackProp_TrackType          IN/OUT: Type of track (Audio, Data, DataMode2, Blank)
		TrackProp_RecordMode        = 5,  // TrackProp_RecordMode_Type    IN/OUT: Recording mode
		TrackProp_SessionNum        = 6,  // UInt32                       IN/OUT: Session number
		TrackProp_StartAddr         = 7,  // UInt32                       IN/OUT: Start address of track in blocks
		TrackProp_Length            = 8,  // UInt32                       IN/OUT: Length of track in blocks
		TrackProp_RecLength         = 9,  // UInt32                       IN/OUT: Recorded length of track in blocks
		TrackProp_AppendAddr        = 10, // UInt32                       IN/OUT: Append address of track in blocks
		TrackProp_State             = 11, // TrackProp_IOState            IN/OUT: Track state
		TrackProp_CurFormatType     = 12, // UInt32                       IN/OUT: Current format type of track
		TrackProp_FormatTypes       = 13, // UInt32[]                     IN/OUT: Format types for tracks
		TrackProp_Copyrighted       = 14, // UInt32                       IN/OUT: Copyrighted
		TrackProp_Pregap            = 15, // UInt32                       IN/OUT: Pregap size in blocks
		TrackProp_ISRC              = 16, // UnicodeString                IN/OUT: ISRC
		TrackProp_CDText_Title      = 17, // UnicodeString                IN/OUT: CD-Text track title
		TrackProp_CDText_Performer  = 18, // UnicodeString                IN/OUT: CD-Text track performer
		TrackProp_CDText_Songwriter = 19, // UnicodeString                IN/OUT: CD-Text track songwriter
		TrackProp_CDText_Composer   = 20, // UnicodeString                IN/OUT: CD-Text track composer
		TrackProp_CDText_Arranger   = 21, // UnicodeString                IN/OUT: CD-Text track arranger
		TrackProp_CDText_Message    = 22, // UnicodeString                IN/OUT: CD-Text track message
		TrackProp_NumExtents        = 23, // UInt32                       IN/OUT: Number of extents in track
		TrackProp_Postgap           = 24, // UInt32                       IN: Postgap size in blocks
		TrackProp_CDText_Genre      = 25, // UnicodeString                IN/OUT: CD-Text track genre
		TrackProp_CDText_GenreCode  = 26, // UnicodeString                IN/OUT: CD-Text track genre code
		TrackProp_LastRecAddr       = 27  // UInt32                       IN/OUT: Last recorded address in blocks
	};

	enum ExclusiveAccess_Type
	{
		ExclusiveAccess_Obtain       = 1,
		ExclusiveAccess_Quick_Obtain = 2,
		ExclusiveAccess_Release      = 3,
		ExclusiveAccess_Query        = 4
	};

	// Register for device arrival/departure notification types
	enum SetCallbackType
	{
		Callback_Register   = 1,
		Callback_Unregister = 2
	};

	enum Event_Type
	{
		EventMediaRemoval  = 1, // Media disappeared
		EventMediaArrival  = 2, // New media or changed media is ready
		EventDeviceChanged = 6, // Drive(s) added or removed, client must refresh the device count
		EventDeviceArrival = 6, // DEPRECATED: Drive appeared (This reports all drive changes, not just arrivals)
		EventDeviceRemoval = 7  // DEPRECATED: Drive disappeared (This was never implemented)
	};

	// Function typedef for reporting progress information
	// Used in AS_StorageDevice_EraseMedia and AS_StorageDevice_Copy
	enum Info
	{
		Info_ProgressUpdate         = 1, // infoDword = percent complete, infoPtr = Progress structure
		Info_PromptForMediaInDevice = 2, // infoDword = unused, infoPtr = unused
		Info_PromptForAlertRetry    = 3, // infoDword = unused, infoPtr = ProgressStatus is valid for error needing client assistance
	};

	// Additional progress info (beyond percent complete)
	struct Progress
	{
		UInt32 ValidBytes;              // Size, in bytes, that follow that are valid
		                                // so this structure can be expanded to return
		                                // additional information in the future
		UInt32 CurrentSector;           // How many sectors have been processed
		                                // (not the actual current sector number)
		UInt32 TotalSectors;            // Total number of sectors to be processed
		UInt32 DeviceInfo;              // Media handle for which this progress is reported
		AS_StorageError ProgressStatus; // AS_StorageError for current operation
		UInt32 CurrentOperation;        // JobType describing the current operation
	};

	// Progress constants for detailed callback info
	typedef UInt32 JobType;
	// INTERNAL NOTE: Defines from EPX Job operation values
	static const JobType JobType_Writing       = 0x00000003;
	static const JobType JobType_Reading       = 0x00000004;
	static const JobType JobType_Comparing     = 0x00000005;
	static const JobType JobType_Formatting    = 0x00000006;
	static const JobType JobType_Erasing       = 0x00000007;
	static const JobType JobType_Initializing  = 0x00000008;
	static const JobType JobType_Finalizing    = 0x00000009;
	static const JobType JobType_Aborting      = 0x0000000a;
	static const JobType JobType_WriteFilemark = 0x0000000b;
	static const JobType JobType_Seek          = 0x0000000c;
	static const JobType JobType_Idle          = 0x00010000;

	// JobStatus: This type is DEPRECATED
	//            Callbacks report AS_StorageError now rather than JobStatus
	typedef UInt32 JobStatus;
	static const JobStatus JobStatus_Success        = 0;
	static const JobStatus JobStatus_Running        = 1;
	static const JobStatus JobStatus_BusyAborting   = 2;
	static const JobStatus JobStatus_Idle           = 0x10000;
	static const JobStatus JobStatus_PartialSuccess = (0x20000 | 0x0000);
	static const JobStatus JobStatus_Aborted        = (0x20000 | 0x0006);
	static const JobStatus JobStatus_Error          = 0xfffe0000;

	typedef UInt32 CopyFlags;
	static const CopyFlags CopyFlags_Write                          = 1;
	static const CopyFlags CopyFlags_TestMode                       = 2;
	static const CopyFlags CopyFlags_Compare                        = 3;
	static const CopyFlags CopyFlags_CompareData                    = 4;
	static const CopyFlags CopyFlags_VerifylessWrite                = 5;     // Warning: can create bad media without error
	                                                                         // Client must validate target media in this mode
	static const CopyFlags CopyFlags_VNR                            = 6;     // Only works with BD-R

	// Advanced copy flags not available in most SDKs
	static const CopyFlags CopyFlags_QflixPro                       = 0x100; // Sonic Qflix Pro (CSS writing) (not enabled in most SDKs)
	static const CopyFlags CopyFlags_GuardBlock                     = 0x200; // Sonic GuardBlock (Bad block writing) (not enabled in most SDKs)
	static const CopyFlags CopyFlags_Qflix                          = 0x300; // Sonic Qflix (CSS writing) (not enabled in most SDKs)
	static const CopyFlags CopyFlags_Compare_CopyProtection         = 7;     // Compare a source to a Qflix Pro destination which has copy protection applied (not enabled in most SDKs)
	static const CopyFlags CopyFlags_Compare_ConsumerCopyProtection = 8;     // Compare a source to a Qflix consumer or DVD download destination which has copy protection applied (not enabled in most SDKs)

	// Function typedef for reporting progress or other information
	// Used in AS_StorageDevice_EraseMedia and other device functions taking callback parameter
	typedef AS_StorageError(AS_CALLBACK *InfoCallback)(const Info& info,
							UInt32 infoDword, void* infoPtr, void* callerUse);

	// Function typedef for receiving device event information
	// Used to alert client of device/media presence
	typedef void (AS_CALLBACK * EventCallback)
	(
		enum Event_Type Event, // Event - device arrival, device departure
		Handle Device,         // Handle to device in which the event occurred
		void* CallerUse        // Caller gets their PVOID back that they registered with
	);

	// Device error as reported by AS_StorageDevice_GetError
	typedef struct
	{
		UInt8 valid;     // Represents if the following information is valid. Once queried it is reset
		UInt8 cmd;       // These four bytes may be reported to Sonic for further information on the error
		UInt8 key;
		UInt8 code;
		UInt8 qual;
		UInt8 other[16]; // This may be dumped to a log file for more detail on the error
	} Error;
};	// AS_StorageDevice


//-----------------------------------------------
// API functions
//-----------------------------------------------

//-----------------------------------------------------------------------------
// AS_GetStorageDeviceCount
//
// DESCRIPTION:
//  Returns a count of the devices on the system using the parameter 'count'.
//  Depending on the value specified by the parameter 'flags', the count may
//  cover all devices, optical devices only, or tape devices only. This method
//  is optional for Windows CE, where only one known device may exist. The
//  'flags' parameter is a bit-mask to allow scanning for multiple types. To
//  count all devices on a system, set the 'flags' parameter to
//  AS_StorageDevice::Scan_All.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if the flags are not defined
//  AS_StorageError_DeviceSelected   - if there are devices currently in use by the SDK,
//                                     (reported to close all devices prior to scanning)
//  AS_StorageError_Fatal            - unknown software error
//
AS_StorageError AS_API AS_GetStorageDeviceCount(
	AS_StorageDevice::Scan_Flags flags, // IN: Flags specifying the type of count to perform
	UInt32& count);                     // OUT: Number of devices found using the given 'flags'

//-----------------------------------------------------------------------------
//AS_OpenStorageDevice
//
// DESCRIPTION:
//  Sets the default device for device-related calls using the OS-provided
//  drive index specified by the parameter 'index'. A device reference
//  (AS_StorageDevice struct) is set using the 'device' parameter and is used
//  to specify the device in subsequent device-related calls.
//
// NOTES:
//  1. This function must be called before any other device-related calls.
//  2. The value of 'index' must be less than the count output by
//     AS_GetStorageDeviceCount.
//  3. There are three types of devices opened with AS_OpenStorageDevice:
//     Physical devices, File devices and Virtual devices.
//
//     Physical: AS_OpenStorageDevice(DeviceIndex, MyDevice);
//         File: AS_OpenStorageDevice(0, MyDevice, AS_StringW(FileName));
//      Virtual: AS_OpenStorageDevice(0, MyDevice, AS_StringA(""));
//
// RETURN:
//  AS_StorageError_None         - ok
//  AS_StorageError_InvalidIndex - if the index provided is greater than the count provided by AS_GetStorageDeviceCount
//  AS_StorageError_Fatal        - failed to create a list of valid drives
//
AS_StorageError AS_API AS_OpenStorageDevice(
	UInt32 index,                         // IN: OS-provided drive index of the drive to open
	AS_StorageDevice& device,             // OUT: Device reference that represents the selected device
	const AS_String& path = AS_String()); // IN (Optional): File path to use for files represented as devices

//-----------------------------------------------------------------------------
// AS_StorageDevice_Close
//
// DESCRIPTION:
//  Closes the specified device and releases all associated memory.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - device handle is invalid.
//
AS_StorageError AS_API AS_StorageDevice_Close(
	AS_StorageDevice& device); // IN/OUT: Device reference specifying the device to close

//-----------------------------------------------------------------------------
// AS_StorageDevice_GetState
//
// DESCRIPTION:
//  Accesses the specified device and returns the device state. Please see the
//  DeviceState enum for details.
//
// NOTES:
//  Calling this method will attempt to access any media in the device.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - device handle is invalid.
//
AS_StorageError AS_API AS_StorageDevice_GetState(
	const AS_StorageDevice& device,        // IN: Device reference
	AS_StorageDevice::DeviceState& state); // OUT: Current DeviceState

//-----------------------------------------------------------------------------
// AS_StorageDevice_ExclusiveAccess
//
// DESCRIPTION:
//  Exclusive Access: Get, set or query the status of exclusive access for a
//  device.
//
// NOTES:
//  A successful call made using ExclusiveAccess_Obtain must be followed by
//  ExclusiveAccess_Release when exclusive access is no longer needed or
//  before the device is closed.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_DeviceError      - if the drive is already in use when trying to obtain
//  AS_StorageError_DeviceInUse      - if the drive is already in use when trying to obtain
//  AS_StorageError_InvalidParameter - invalid drive handle or invalid 'accessType' flag
//
AS_StorageError AS_API AS_StorageDevice_ExclusiveAccess(
	const AS_StorageDevice& device,                    // IN: Device reference
	AS_StorageDevice::ExclusiveAccess_Type accessType, // IN: Desired access type
	const AS_String& accessName,                       // IN: Name of calling application
	AS_String& appInUseName);                          // OUT: Name of application currently using drive, if in use.

//-----------------------------------------------------------------------------
// AS_SetStorageDeviceCallback
//
// DESCRIPTION:
//  Register for callbacks - receive a notification when a new drive arrives,
//  or when new media arrives in a drive.
//
// NOTES:
//  1. Current drive which has been exclusively obtained will not report media
//     notifications.
//  2. If all opened AS_StorageDevice(s) have been closed, it is necessary to
//     call this method again to continue to receive notifications.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - device handle is invalid or invalid Callback flag
//  AS_StorageError_Fatal            - failed to create a list of valid drives
//
AS_StorageError AS_API AS_SetStorageDeviceCallback(
	AS_StorageDevice::SetCallbackType regType, // IN: Register or unregister flag
	UInt32 reserved1,                          // IN: Reserved for future use
	AS_StorageDevice::EventCallback callback,  // IN: Event callback function used to receive notifications
	void* userData,                            // IN: Event callback user data
	void* reserved2);                          // IN: Reserved for future use

//-----------------------------------------------------------------------------
// AS_StorageDevice_TrayControl
//
// DESCRIPTION:
//  Used to control operation (lock, unlock, open, close, etc.) of the media
//  tray of the specified device.
//
// NOTES:
//  An error will result if the device is currently in use.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_DeviceError      - the device reported an error.
//  AS_StorageError_InvalidParameter - the device handle provided is invalid.
//
AS_StorageError AS_API AS_StorageDevice_TrayControl(
	const AS_StorageDevice& device,              // IN: Device reference
	AS_StorageDevice::TrayControls trayControl); // IN: Desired tray control operation

//-----------------------------------------------------------------------------
// AS_StorageDevice_GetDeviceProperty
//
// DESCRIPTION:
//  Retrieves the value of a property of the specified device. The type of
//  property (device type, supported media types, etc.) is specified with the
//  parameter 'deviceProperty'. The buffer to which the property should be
//  written is specified by 'propertyBuffer' whose size is specified by
//  'bufferSize'. If the call completes successfully, the actual size of the
//  property's available data is set using 'retDataSize'.
//
//  The extended optional parameters allow for additional property data to be
//  retrieved. If the extended data is a list, then the value of the property
//  at index 'propertyIndex' is copied to 'extPropertyBuffer' whose size is
//  specified by 'extBufferSize'. If 'propertyIndex' is 0xffffffff, then the
//  whole list is returned. If the extended data is not a list of items, then
//  the 'propertyIndex' parameter is ignored.
//
// NOTES:
//  To query only the size of the property data, specify 'propertyBuffer' as
//  NULL and 'bufferSize' as zero; 'retDataSize' will be set to the number of
//  required or available bytes. The 'extRetDataSize' parameter works in a
//  similar manner. Please note that not all properties support additional
//  property information.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - device handle is invalid or buffer size can't hold return value
//  AS_StorageError_BufferOverflow   - if the buffer is not large enough for the DevProp_DrivePath of file devices
//  AS_StorageError_DeviceError      - the device reported an error
//
AS_StorageError AS_API AS_StorageDevice_GetDeviceProperty(
	const AS_StorageDevice& device,                // IN: Device reference
	AS_StorageDevice::DevProp_Type deviceProperty, // IN: Device property to return
	UInt32 bufferSize,                             // IN: Size of 'propertyBuffer' in bytes
	void* propertyBuffer,                          // OUT: Buffer that is to hold the data retrieved for the specified property
	UInt32* retDataSize,                           // OUT: Required/Available size in bytes of the requested property data
	UInt32 propertyIndex = 0,                      // IN (Optional): List index of the property to return - only used for properties which are lists
	UInt32 extBufferSize = 0,                      // IN (Optional): Size of 'extPropertyBuffer' in bytes
	void* extPropertyBuffer = 0,                   // IN/OUT (Optional): Buffer that is to hold the extended property data
	UInt32* extRetDataSize = 0);                   // OUT (Optional): Required/Available size in bytes of the extended property data

//-----------------------------------------------------------------------------
// AS_StorageDevice_SetDeviceProperty
//
// DESCRIPTION:
//  Sets the value of a property of the specified device. The property to set
//  is specified with the parameter 'deviceProperty'. The buffer from which the
//  new value of the property should be written is specified with
//  'propertyBuffer' whose size is specified by 'bufferSize'.
//
//  The extended optional parameters allow for additional property data to be
//  set. If the extended data is a list, then the value of the property at
//  index 'propertyIndex' is given in 'extPropertyBuffer' whose size is
//  specified by 'extBufferSize'. If 'propertyIndex' is 0xffffffff, then the
//  whole list is set. If the extended data is not a list of items, then the
//  'propertyIndex' parameter is ignored.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - device handle is invalid or buffer size can't hold return value.
//  AS_StorageError_DeviceError      - the device reported an error.
//  AS_StorageError_DeviceNotReady   - device reports no media.
//
AS_StorageError AS_API AS_StorageDevice_SetDeviceProperty(
	AS_StorageDevice& device,                      // IN: Device reference
	AS_StorageDevice::DevProp_Type deviceProperty, // IN: Device property to set
	UInt32 bufferSize,                             // IN: Size of 'propertyBuffer' in bytes
	void* propertyBuffer,                          // IN: Buffer that holds the data to set for the specified property
	UInt32 propertyIndex = 0,                      // IN (Optional): List index of property to set - only used for properties which are lists
	UInt32 extBufferSize = 0,                      // IN (Optional): Size of 'extPropertyBuffer' in bytes
	void* extPropertyBuffer = 0);                  // IN/OUT (Optional): Buffer that holds the extended data to set

//-----------------------------------------------------------------------------
// AS_StorageDevice_GetMediaProperty
//
// DESCRIPTION:
//  Retrieves the current value of a property of the media in the specified
//  device. The type of property (number of layers, media type, media state,
//  etc.) is specified with the parameter 'mediaProperty'. The buffer to which
//  the property should be written is specified by 'propertyBuffer' whose size
//  is specified by 'bufferSize'. If the call completes successfully, the
//  actual size of the property's available data is set using 'retDataSize'.
//
//  The extended optional parameters allow for additional property data to be
//  retrieved. If the extended data is a list, then the value of the property
//  at index 'propertyIndex' is copied to 'extPropertyBuffer' whose size is
//  specified by 'extBufferSize'. If 'propertyIndex' is 0xffffffff, then the
//  whole list is returned. If the extended data is not a list of items, then
//  the 'propertyIndex' parameter is ignored.
//
// NOTES:
//  To query only the size of the property data, specify 'propertyBuffer' as
//  NULL and 'bufferSize' as zero; 'retDataSize' will be set to the number of
//  required or available bytes. The 'extRetDataSize' parameter works in a
//  similar manner.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - device handle is invalid or buffer size can't hold return value.
//  AS_StorageError_DeviceError      - the device reported an error.
//  AS_StorageError_DeviceNotReady   - device reports no media.
//
AS_StorageError AS_API AS_StorageDevice_GetMediaProperty(
	const AS_StorageDevice& device,                 // IN: Device reference
	AS_StorageDevice::MediaProp_Type mediaProperty, // IN: Media property to return
	UInt32 bufferSize,                              // IN: Size of 'propertyBuffer' in bytes
	void* propertyBuffer,                           // OUT: Buffer to hold the data retrieved for the specified property
	UInt32* retDataSize,                            // OUT: Required/Available size in bytes of the requested property data
	UInt32 propertyIndex = 0,                       // IN (Optional): List index of property to return - only used for properties which are lists
	UInt32 extBufferSize = 0,                       // IN (Optional): Size of 'extPropertyBuffer' in bytes
	void* extPropertyBuffer = 0,                    // IN/OUT (Optional): Buffer that is to hold the extended property data
	UInt32* extRetDataSize = 0);                    // OUT (Optional): Required/Available size in bytes of the extended property data

//-----------------------------------------------------------------------------
// AS_StorageDevice_SetMediaProperty
//
// DESCRIPTION:
//  Sets a property value of the media in the specified device. The property
//  to set is specified with the parameter 'mediaProperty'. The buffer from
//  which the new value of the property should be written is specified with
//  'propertyBuffer' whose size is specified by 'bufferSize'.
//
//  The extended optional parameters allow for additional property data to be
//  set. If the extended data is a list, then the value of the property at
//  index 'propertyIndex' is given in 'extPropertyBuffer' whose size is
//  specified by 'extBufferSize'. If 'propertyIndex' is 0xffffffff, then the
//  whole list is set. If the extended data is not a list of items, then the
//  'propertyIndex' parameter is ignored.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - device handle is invalid or buffer size can't hold return value.
//  AS_StorageError_DeviceError      - the device reported an error.
//  AS_StorageError_DeviceNotReady   - device reports no media.
//
AS_StorageError AS_API AS_StorageDevice_SetMediaProperty(
	const AS_StorageDevice& device,                 // IN: Device reference
	AS_StorageDevice::MediaProp_Type mediaProperty, // IN: Media property to set
	UInt32 bufferSize,                              // IN: Size of 'propertyBuffer' in bytes
	void* propertyBuffer,                           // IN: Buffer that holds the data to set for the specified property
	UInt32 propertyIndex = 0,                       // IN (Optional): List index of property to set - only used for properties which are lists
	UInt32 extBufferSize = 0,                       // IN (Optional): Size of 'extPropertyBuffer' in bytes
	void* extPropertyBuffer = 0);                   // IN/OUT (Optional): Buffer that holds the extended data to set for the specified property

//-----------------------------------------------------------------------------
// AS_StorageDevice_SetTrackProperty
//
// DESCRIPTION:
//  Sets a property value of a track on the media in the specified device.
//  The property to set is specified with the parameter 'trackProperty'. The
//  buffer from which the new value of the property should be written
//  is specified with 'propertyBuffer' whose size is specified by 'bufferSize'.
//
//  The extended optional parameters allow for additional property data to be
//  set. If the extended data is a list, then the value of the property at
//  index 'propertyIndex' is given in 'extPropertyBuffer' whose size is
//  specified by 'extBufferSize'. If 'propertyIndex' is 0xffffffff, then the
//  whole list is set. If the extended data is not a list of items, then the
//  'propertyIndex' parameter is ignored.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - device handle is invalid or buffer size can't hold return value.
//  AS_StorageError_DeviceError      - the device reported an error.
//  AS_StorageError_DeviceNotReady   - device reports no media.
//
AS_StorageError AS_API AS_StorageDevice_SetTrackProperty(
	const AS_StorageDevice& device,                 // IN: Device reference
	UInt32 trackNum,                                // IN: Track number
	AS_StorageDevice::TrackProp_Type trackProperty, // IN: Track property to set
	UInt32 bufferSize,                              // IN: Size of 'propertyBuffer' in bytes
	void* propertyBuffer,                           // IN: Buffer that holds the data to set for the specified property
	UInt32 propertyIndex = 0,                       // IN (Optional): List index of property to set - only used for properties which are lists
	UInt32 extBufferSize = 0,                       // IN (Optional): Size in bytes of 'extPropertyBuffer'
	void* extPropertyBuffer = 0);                   // IN/OUT (Optional): Buffer that holds the extended data to set

//-----------------------------------------------------------------------------
// AS_StorageDevice_GetTrackProperty
//
// DESCRIPTION:
//  Retrieves a current property value of a track on the media in the
//  specified device. The type of property (length, start address, pregap,
//  etc.) is specified with the parameter 'trackProperty'. The buffer to which
//  the property should be written is specified with 'propertyBuffer' whose
//  size is specified by 'bufferSize'. If the call completes successfully, the
//  actual size of the property's available data is set using 'retDataSize'.
//
//  The extended optional parameters are provided to obtain additional property
//  data. If the extended data is a list, then the value of the property at
//  index 'propertyIndex' is set in 'extPropertyBuffer' whose size is specified
//  by 'extBufferSize'. If 'propertyIndex' is 0xffffffff, then the whole list
//  is obtained. If the extended data is not a list of items, then the
//  'propertyIndex' parameter is ignored.
//
// NOTES:
//  To query only the size of the property data, specify 'propertyBuffer' as
//  NULL and 'bufferSize' as zero; 'retDataSize' will be set to the number of
//  required or available bytes. The 'extRetDataSize' parameter works in a
//  similar manner.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - device handle is invalid.
//
AS_StorageError AS_API AS_StorageDevice_GetTrackProperty(
	const AS_StorageDevice& device,                 // IN: Device reference
	UInt32 trackNum,                                // IN: Track number to get property of
	AS_StorageDevice::TrackProp_Type trackProperty, // IN: Track property to return
	UInt32 bufferSize,                              // IN: Size of 'propertyBuffer' in bytes
	void* propertyBuffer,                           // OUT: Buffer to hold the data retrieved for the specified property
	UInt32* retDataSize,                            // OUT: Required/Available size in bytes of the requested property data
	UInt32 propertyIndex = 0,                       // IN (Optional): List index of property to return - only used for properties which are lists
	UInt32 extBufferSize = 0,                       // IN (Optional): Size of 'extPropertyBuffer' in bytes
	void* extPropertyBuffer = 0,                    // OUT (Optional): Buffer to hold the extended property data
	UInt32* extRetDataSize = 0);                    // OUT (Optional): Required/Available size of the requested extended property data

//-----------------------------------------------------------------------------
// AS_StorageDevice_GetError
//
// DESCRIPTION:
//  This API reports more detailed information about error codes that were reported
//  from the device.  Only when the AS_StorageError return code
//  AS_StorageError_DeviceSenseError is received is more information available.
//
// NOTES:
//  This will most commonly be used in the callback function during operations.
//  There are 2 callbacks in particular that would receive AS_StorageError_DeviceSenseError
//  return codes.
//  - AS_StorageDevice::InfoCallback
//  - AS_Volume::InfoCallback
//  The caller has a list of AS_StorageDevice objects that is being used for a particular
//  operation.  In the sample app, we pass that list to the callback in the callerUse
//  field.  The callbacks will get called for each device in the operation.  There is
//  1 message in particular to look for in each callback:
//  - AS_StorageDevice::InfoCallback, if the info parameter is
//    AS_StorageDevice::Info_ProgressUpdate, the infoPtr parameter will contain a pointer
//    to a AS_StorageDevice::Progress structure.  The Progress->DeviceInfo member is
//    a handle to the AS_StorageDevice that this callback is referencing.  You can match
//    that value to the AS_StorageDevice->myHandle member of the AS_StorageDevices that
//    are part of the operation.  The one that matches is the AS_StorageDevice object that
//    the callback is for.  Use that AS_StorageDevice for the AS_StorageDevice_GetError call
//    to get the sense information reported for that device.
//  - AS_Volume::InfoCallback, if the info parameter is AS_Volume::Info_ProgressUpdate,
//    the infoPtr parameter will contain a pointer to a  AS_Volume::Progress structure.
//    The Progress->DeviceHandle member is a handle to the AS_StorageDevice that this callback
//    is referencing.  You can match that value to the AS_StorageDevice->myHandle member
//    of the AS_StorageDevices that are part of the operation.  The one that matches is the
//    AS_StorageDevice object that the callback is for.  Use that AS_StorageDevice for the
//    AS_StorageDevice_GetError call to get the sense information reported for that device.
// In the sample app, see the following functions for sample code:
//  DeviceInfo_Callback (This is a AS_StorageDevice::InfoCallback)
//  Info_Callback (This is a AS_Volume::InfoCallback)
//  Callbacks::GetStorageDeviceFromCallerUse (This compares the handle in the callback to the
//                AS_StorageDevice object list passed into the callerUse to find the matching
//                AS_StorageDevice object)
//  OutputUtils::AS_StorageErrorToString (This calls AS_StorageDevice_GetError when an
//                AS_StorageError_DeviceSenseError is received using the AS_StorageDevice
//                object that we matched)
//
AS_StorageError AS_API AS_StorageDevice_GetError( // RETURNS: Last drive error number
	const AS_StorageDevice& device,               // IN: Device reference
	UInt32 structureVersion,                      // IN: Size of structure to fill (see Error struct)
	AS_StorageDevice::Error* err);                // OUT: Error structure to hold sense information

//-----------------------------------------------------------------------------
// AS_StorageDevice_EraseMedia
//
// DESCRIPTION:
//  Erases the media, if any, in the specified device. The type of erase
//  operation to perform (quick or long) is specified with the parameter
//  'eraseType'. A callback with which the AuthorScript engine will report the
//  progress of the erasure is specified with 'callback'. The parameter
//  'userData' allows the host application to specify a pointer to a memory
//  location that will be passed back whenever AuthorScript calls the callback.
//
// NOTES:
//  The device state must be State_Ready (see AS_StorageDevice_GetState).
//  An error will result if the device is currently in use by an AuthorScript
//  Imaging project.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - invalid drive handle
//  AS_StorageError_DeviceError      - the device reported an error
//
AS_StorageError AS_API AS_StorageDevice_EraseMedia(
	const AS_StorageDevice& device,          // IN: Device holding the media to erase
	AS_StorageDevice::Erase_Type eraseType,  // IN: Type of erase: Quick_Erase, Long_Erase
	AS_StorageDevice::InfoCallback callback, // IN: Progress callback function
	void* userData);                         // IN: Progress callback user data

//-----------------------------------------------------------------------------
// AS_StorageDevice_Copy
//
// DESCRIPTION:
//  Copies from a source to destination(s). The type of copy is specified with
//  the "flag" parameter. Set "trackNum" to zero in order to copy the entire
//  disc, otherwise only the selected track is copied.
//
// NOTES:
//  Currently only a single file format type can be specified for the
//  destination(s).
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - invalid drive handle
//  AS_StorageError_DeviceError      - the device reported an error
//
AS_StorageError AS_API AS_StorageDevice_Copy(
	const AS_StorageDevice& srcDevice,       // IN: Source device to copy from
	AS_StorageDevice::FileFormatType format, // IN: Format type setting for destination file(s)
	AS_StorageDevice::CopyFlags flag,        // IN: Copy parameter flags
	UInt32 trackNum,                         // IN: One-based track to copy: Zero denotes all tracks (entire disc)
	UInt32 numDevices,                       // IN: Number of destinations
	const AS_StorageDevice* deviceList,      // IN: Array of destination devices
	AS_StorageDevice::InfoCallback callback, // IN: Progress callback function
	void* userData);                         // IN: Progress callback user data

#ifdef __cplusplus
}
#endif

#endif //__AS_StorageDevice_h__
